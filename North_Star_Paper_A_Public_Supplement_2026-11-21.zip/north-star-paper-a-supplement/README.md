# Reconstructing Unions of Subgroups from Cyclic Autocorrelation

**Robert Gillon · Paper A · 100-odd-prime revision · 21 November 2026**

This directory is the **public-ready source and supplementary material (S1)** for the paper. It contains the revised manuscript PDF, the complete source, exact arithmetic certificates, and reproducible checks. It does **not** claim a Lean formal proof or an arithmetic classification of all cyclic moduli.

The construction gives distinct subgroup unions with identical full labeled cyclic autocorrelation at

\[N=2^{3446}M_{100},\qquad \omega(M_{100})=100.\]

## Start here

- [`Paper_A_Reconstructing_Subgroup_Unions_100_Primes.pdf`](Paper_A_Reconstructing_Subgroup_Unions_100_Primes.pdf) — revised 25-page manuscript, with private GitHub references replaced by self-contained Supplement S1 citations.
- [`docs/Paper_A_Review_Dossier.pdf`](docs/Paper_A_Review_Dossier.pdf) — roadmap, proof dependencies, response to AI referee report.
- [`docs/Paper_A_Lean_Status_Report.pdf`](docs/Paper_A_Lean_Status_Report.pdf) — formalization status; **no Lean proof certificate exists** in this release.
- [`manuscript/paper-a/construction-proofs/PPI_100_PRIME_PAIR.md`](manuscript/paper-a/construction-proofs/PPI_100_PRIME_PAIR.md) — deterministic H100 construction proof record.
- [`manuscript/paper-a/review/REVIEWER_GUIDE.md`](manuscript/paper-a/review/REVIEWER_GUIDE.md) — suggested reading order.

## Exact reproduction

Run these commands from **this directory**, with Python 3.12 and assertions enabled (do not use `-O`):

```sh
python3 -m pip install -r requirements-h100.txt
python3 experiments/ppi_100_prime_pair.py
python3 experiments/ppi_h100_independent_audit.py experiments
python3 experiments/ppi_h100_decoder_audit.py experiments
python3 manuscript/paper-a/review/numerics/verify_h100_error_budget.py experiments h100_error_budget_replay.json
```

The original script checks 435 constructed target masses; the independent decoder audit checks 2,175. The prime checks cover all 100 distinct odd prime factors. The full all-shift homometry theorem relies on the algebraic convolution argument and a universal nesting/interval proof, **not** enumeration of all shifts in the enormous group.

For the 38-modulus finite graph domain, use a C++17 compiler:

```sh
g++ -std=c++17 -O2 manuscript/paper-a/graph-controls/replay_graph.cpp -o replay_graph
./replay_graph < manuscript/paper-a/graph-controls/replay_moduli.txt > graph_counts_new.txt
diff -u manuscript/paper-a/graph-controls/replay_counts.txt graph_counts_new.txt
```

The recorded total is 1,468,606 subgroup-union profiles. The optional NumPy/Numba implementations have separate dependencies and have **not** been rerun as part of this packaging. See the archived replay report for scopes.

## Integrity and limitations

`SHA256SUMS` provides SHA-256 checksums for the published files, excluding itself. To verify the contents, run `sha256sum -c SHA256SUMS` from the root. The source files in this release are enough to replay the core results without access to the private North Star research repository. Later research on prime-factorization classification is deliberately excluded.

This is a **research preprint and computation supplement**, not journal peer review. AI-assisted evaluations share model/context limitations. Independent human review is welcome. No formal Lean build is claimed.

### Publication status

This directory is prepared for a standalone public GitHub repository; publication to GitHub requires creating or selecting a public repository under the author's account. The links inside this README are **relative** and will work wherever the directory is hosted. No unverified public repository URL is asserted.
