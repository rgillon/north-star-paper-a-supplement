# Independent reviewer: provenance and scope

This public-ready source tree is an exported, self-contained subset of a private research workspace. You do not need access to the original `rgillon/north-star-math` repository, and you do not need to run its history-dependent setup. The constructed modulus and both sets are determined by the included certificate JSON and deterministic sources.

The 20 November source pin `09d77232d96df1e16ef52917ddf46ccff90deb0b` and the 21 November support baseline `2ddc150f363da5ae410ed4ac1de573e7cbd7bb80` are provenance identifiers only. They are *not* publicly reachable promises. For this edition, use the accompanying code and data in `experiments/` and `manuscript/paper-a/graph-controls/`.

The H100 exact programs and graph replay passed when this package was prepared. The manuscript's universal all-shift claim rests on the symbolic convolution identity and the nesting / grid lemmas. Those mathematical proofs still require independent scrutiny. A Lean status PDF is provided; it describes the absence of a replayable Lean formalization, not a Lean certificate.

The paper's full prime-factorization classification, least nonrigid modulus, least dyadic height, and unrestricted 4M case remain open. Later speculative research is not presented as proved in this release.
