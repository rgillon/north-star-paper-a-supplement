# Publish this standalone supplement to a public GitHub repository

**Status: not published to GitHub as part of this file build.** This package is ready to be published, but the connected GitHub app does not currently offer repository creation or a change-of-visibility operation. Do **not** change the visibility of `rgillon/north-star-math`: it contains unrelated private research.

## Easiest path

1. Sign into GitHub and open <https://github.com/new>.
2. Select owner **rgillon**. Name the repository **north-star-paper-a** (or choose another unambiguous name).
3. Choose **Public**. Leave **Add a README**, `.gitignore`, and license unchecked; this package supplies the relevant files.
4. Create the repository.
5. Upload the contents of this directory, preserving the paths, by Git/GitHub Desktop. The CLI route follows.
6. Open the new public repository from a browser **while logged out** to confirm that its PDF, README, certificate JSON, three H100 scripts, and graph control C++ file can be viewed.
7. Copy the public URL and the full release commit SHA; a subsequent manuscript edition can add a stable commit-pinned URL without guessing it.

## Terminal route (after you have created the empty public repository)

From the directory containing this README (and after installing Git):

```sh
git init -b main
git add .
git commit -m "Publish Paper A manuscript and H100 reproducibility supplement"
git remote add origin https://github.com/rgillon/north-star-paper-a-supplement.git
git push -u origin main
```

If you chose a different repository name, replace it in `git remote add origin`. GitHub will request authentication in your Git credential manager. **Do not put access tokens or passwords in any file in this archive.**

If the GitHub CLI is already authenticated on your computer, it can create and publish the public repository in one step from the source directory:

```sh
git init -b main
git add .
git commit -m "Publish Paper A manuscript and H100 reproducibility supplement"
gh repo create rgillon/north-star-paper-a-supplement --public --source . --remote origin --push
```

The commands are **instructions**, not actions that were run in this session. No live public URL is claimed by this document.

## Permanent citation

For long-term reproducibility, make a release/tag such as `paper-a-h100-v1` after checking the public files, and reference a specific release or commit rather than the mutable `main` branch. The manuscript currently cites **Supplementary Material S1** so it remains reviewable together with the downloaded archive even before a GitHub repository exists. Add the pinned public URL to the bibliography only after the actual release can be opened anonymously.
