// Emit the canonical list of 2^24 disjoint equal-sum prime quartets.
// Usage: ppi_damping_stream < excluded-primes.txt | sha256sum
// Each output line has four decimal primes, in positive-pair then negative-pair order.
#include <algorithm>
#include <array>
#include <charconv>
#include <cstdint>
#include <cstdio>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <vector>

using Number = std::uint32_t;

class Lines {
    std::array<char, 65536> data{};
    char* next = data.data();

public:
    void flush() {
        const auto bytes = static_cast<std::size_t>(next - data.data());
        if (std::fwrite(data.data(), 1, bytes, stdout) != bytes)
            throw std::runtime_error("writing quartet stream failed");
        next = data.data();
    }

    void emit(Number a, Number d, Number b, Number c) {
        if (data.data() + data.size() - next < 48)
            flush();
        const Number fields[] = {a, d, b, c};
        for (std::size_t i = 0; i < 4; ++i) {
            next = std::to_chars(next, data.data() + data.size(), fields[i]).ptr;
            *next++ = (i == 3 ? '\n' : ' ');
        }
    }
};

int run() {
    constexpr Number wanted = Number{1} << 24;
    constexpr std::uint64_t limit = std::uint64_t{1} << 31;
    constexpr std::size_t half_span = 1u << 18;
    constexpr Number root = 46340;

    std::vector<Number> excluded;
    for (Number p; std::cin >> p;)
        excluded.push_back(p);
    if (!std::cin.eof())
        throw std::runtime_error("invalid exclusion list");
    std::sort(excluded.begin(), excluded.end());
    if (excluded.size() != 4262 ||
        std::adjacent_find(excluded.begin(), excluded.end()) != excluded.end())
        throw std::runtime_error("expected 4262 distinct excluded prime axes");
    std::size_t excluded_index = 0;

    std::vector<bool> base_prime(root + 1, true);
    std::vector<Number> primes;
    for (Number p = 3; p <= root; p += 2) {
        if (!base_prime[p])
            continue;
        primes.push_back(p);
        if (p <= root / p)
            for (Number q = p*p; q <= root; q += 2*p)
                base_prime[q] = false;
    }

    std::vector<unsigned char> composite(half_span);
    std::vector<Number> pending;
    Lines lines;
    Number pair_first = 0, emitted = 0;
    for (std::uint64_t lo = 3; lo < limit; lo += 2*half_span) {
        const std::uint64_t hi = std::min(limit, lo + 2*half_span);
        std::fill(composite.begin(), composite.end(), 0);
        for (Number p : primes) {
            if (std::uint64_t(p)*p >= hi)
                break;
            std::uint64_t start = std::max(std::uint64_t(p)*p, (lo+p-1)/p*p);
            if (!(start & 1))
                start += p;
            for (std::uint64_t i = (start-lo)/2; i < (hi-lo+1)/2; i += p)
                composite[i] = 1;
        }
        for (std::size_t i = 0; lo+2*i < hi; ++i) {
            if (composite[i])
                continue;
            const Number p = static_cast<Number>(lo + 2*i);
            while (excluded_index < excluded.size() && excluded[excluded_index] < p)
                ++excluded_index;
            if (excluded_index < excluded.size() && excluded[excluded_index] == p)
                continue;
            if (pair_first == 0) {
                pair_first = p;
                continue;
            }
            const Number gap = p - pair_first;
            if (gap >= pending.size())
                pending.resize(gap + 1, 0);
            if (pending[gap] != 0) {
                const Number a = pending[gap], b = a + gap;
                if (!(a < b && b < pair_first && a+p == b+pair_first))
                    throw std::runtime_error("invalid quartet");
                lines.emit(a, p, b, pair_first);
                pending[gap] = 0;
                if (++emitted == wanted) {
                    lines.flush();
                    std::fprintf(stderr, "quartets=%u\nmaximum_prime=%u\n", emitted, p);
                    return 0;
                }
            } else {
                pending[gap] = pair_first;
            }
            pair_first = 0;
        }
    }
    throw std::runtime_error("prime search exceeded 2^31");
}

int main() {
    try {
        return run();
    } catch (const std::exception& e) {
        std::fprintf(stderr, "%s\n", e.what());
        return 1;
    }
}

