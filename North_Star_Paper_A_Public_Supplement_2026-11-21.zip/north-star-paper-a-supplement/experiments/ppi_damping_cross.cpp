#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <map>
#include <vector>
int main() {
    constexpr std::uint32_t end = 1339577149;
    std::vector<std::uint64_t> mark((std::size_t(end)/2)/64 + 1);
    const auto test = [&](std::uint32_t p) { return (mark[p/128] >> (p/2%64)) & 1; };
    const auto set = [&](std::uint32_t p) { mark[p/128] |= UINT64_C(1) << (p/2%64); };
    for (std::uint32_t p=3; p <= end/p; p+=2) {
        if (!test(p)) for (std::uint32_t q=p*p; q<=end; q+=2*p) set(q);
    }
    for (std::uint32_t p; std::cin >> p;) {
        if (test(p)) return 1;
        set(p);
    }
    std::map<std::uint32_t, std::uint32_t> first_of_gap;
    std::uint32_t prev=0, blocks=0, final=0;
    std::setvbuf(stdout,nullptr,_IOFBF,1024*1024);
    for (std::uint32_t p=3; p<=end; p+=2) {
        if (test(p)) continue;
        if (prev==0) {prev=p;continue;}
        auto entry=first_of_gap.emplace(p-prev,prev);
        if (!entry.second) {
            std::uint32_t a=entry.first->second;
            std::printf("%u %u %u %u\n",a,p,a+entry.first->first,prev);
            ++blocks; final=p; first_of_gap.erase(entry.first);
        }
        prev=0;
    }
    if (blocks!=(1u<<24) || final!=end) return 1;
    std::fprintf(stderr,"dense independent sieve confirmed %u blocks ending at %u\n",blocks,final);
}

