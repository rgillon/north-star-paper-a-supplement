"""Integer checks of concrete marker slots, approximation and capacity bounds.

Requires the adjacent ppi_upper_coprime_donors.py and ppi_lower_shield_pair.py.
Only standard-library operations are used. No enumeration of the enormous
product group or its damping factors is needed.
"""

import sys
from fractions import Fraction
from math import gcd, isqrt, prod

import ppi_lower_shield_pair as lower
import ppi_upper_coprime_donors as upper

H = 1024
T = 1 << 24
PAIR_SUM = (1 << 18) + 2
C_BITS = 80000


def ceil_div(a, b):
    return -(-a // b)


def ceil_log_ratio(a, b):
    """Ceiling of log2(a/b), for a >= b > 0."""
    shift = a.bit_length() - b.bit_length()
    return shift + (a > (b << shift))


def primes_below(limit):
    sieve = bytearray([1]) * limit
    sieve[:2] = bytes(2)
    for i in range(2, isqrt(limit - 1) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytes(len(sieve[i*i::i]))
    return sieve


def v2(x):
    return (x & -x).bit_length() - 1


def donor_data():
    upper_data = [
        (upper.FIRST_HIDDEN, upper.FIRST_FIBERS, upper.FIRST_ZERO_ROWS, 128, 151),
        (upper.SECOND_HIDDEN, upper.SECOND_FIBERS, upper.SECOND_ZERO_ROWS, 12, -500951232),
    ]
    denominators = [upper.donor(*data) for data in upper_data]
    axes = [p for hidden, _, _, _, _ in upper_data for p in hidden]
    upper_bounds = []
    for (_, fibers, _, _, _), denominator in zip(upper_data, denominators):
        primes = [abs(c) for c, _ in fibers]
        axes.extend(primes)
        n = len(primes)
        # The incidence system for alpha has n-1 rows after the redundant
        # row is removed, entries 0/1 and target entries of absolute value
        # <=1. Hadamard's determinant bound and the nonzero integral
        # denominator determinant bound each |alpha| by (n-1)^((n-1)/2).
        # The root is -sum(alpha), and a packet's value relative to its
        # generator value is a product of some (1-p), bounded by prod(p).
        hadamard = isqrt((n - 1) ** (n - 1)) + 1
        assert hadamard <= 10**100
        upper_bounds.append((n - 1) * hadamard * (1 + prod(primes)))
    low = [lower.inspect(c, masks) for c, masks in lower.CASES]
    axes += [abs(c) for case, _ in lower.CASES for c in case]
    assert len(axes) == len(set(axes)) == 166
    d1, d2 = denominators
    assert gcd(d1, d2) == 1
    b_upper = d1 * pow(d1, -1, d2)
    assert 0 <= b_upper < d1*d2 and b_upper % d1 == 0 and (b_upper-1) % d2 == 0
    upper_paired = abs(b_upper)*upper_bounds[0] + abs(1-b_upper)*upper_bounds[1]
    l1, l2 = [d for d,_ in low]
    a, b = l1 >> v2(l1), l2 >> v2(l2)
    assert gcd(a, b) == 1
    k = a * pow(a, -1, b)
    lower_paired = abs(k)*low[0][1] + abs(1-k)*low[1][1]
    denominator_product = d1*d2*l1*l2
    odd = denominator_product >> v2(denominator_product)
    assert max(upper_bounds) < 1 << 2342 and max(d1,d2) < 1 << 2334
    assert upper_paired < 1 << 7014 and lower_paired < 1 << 710
    assert max(l1,l2) < 1 << 600 and max(z for _,z in low) < 1 << 710
    assert max(v2(l1), v2(l2)) <= 32 and odd < 1 << 6000
    assert (1+upper_paired)*(1+lower_paired) < 1 << 8000
    assert (1+max(upper_bounds))*(1+max(z for _,z in low)) < 1 << 8000
    return (set(axes), odd, v2(denominator_product), upper_paired, lower_paired,
            max(upper_bounds), max(z for _,z in low))


def check_small_binary_embedding():
    # Positive and negative shells need not balance for the forward identity
    # below. This tests the full literal binary embedding on C420 and every
    # lag, including the varying common fiber at the incomparable order 5.
    dyad, spectator, quotient = 4, 7, 15
    n = dyad * spectator * quotient
    def heights(y, s):
        order = quotient // gcd(quotient, y)
        if order == 1:
            return 4, 4
        if order == 3:
            return 4, 0
        if order == 5:
            h = 2 if s == 0 else 1
            return h, h
        return 0, 0
    def present(x, side):
        height = heights(x % quotient, x % spectator)[side]
        return int(dyad // gcd(dyad, x) <= height)
    f, g = ([present(x, side) for x in range(n)] for side in (0, 1))
    e = [int(quotient // gcd(quotient, y) == 3) for y in range(quotient)]
    z = [sum(sum(heights(y,s)) for s in range(spectator)) for y in range(quotient)]
    # z = dyad*spectator times the required normalized mean.
    expected = [sum(c*z[(lag-y)%quotient] for y,c in enumerate(e))
                for lag in range(quotient)]
    for lag in range(n):
        actual = sum(f[y]*f[(y+lag)%n]-g[y]*g[(y+lag)%n] for y in range(n))
        assert actual == expected[lag % quotient]


def main(export_excluded=False):
    fixed, odd, denominator_v2, up, low, up_single, low_single = donor_data()
    prime = primes_below(PAIR_SUM)
    pairs = [(p,PAIR_SUM-p) for p in range(3,PAIR_SUM//2)
             if prime[p] and prime[PAIR_SUM-p]]
    eligible = [(p,q) for p,q in pairs if p not in fixed and q not in fixed]
    chosen = eligible[:2*H]
    assert len(pairs) == 2661 and len(eligible) == 2643 and len(chosen) == 2*H
    markers = [p for pair in chosen for p in pair]
    assert len(set(markers)) == 4*H and all(p not in fixed for p in markers)
    if export_excluded:
        for p in sorted(fixed.union(markers)):
            print(p)
        return
    m = PAIR_SUM-2
    for i in range(H):
        p,q = chosen[2*i]
        r,s = chosen[2*i+1]
        assert p+q-2 == r+s-2 == m
    K = prod(markers)
    M = m ** H
    L = (1+2*m)**H - (2*m)**H
    assert M == 1 << 18432
    assert (K.bit_length(),L.bit_length(),M.bit_length()) == (67096,19448,18433)
    n = 166+4*T
    rho = Fraction(M,K)
    theta = Fraction(2*L+M,K)
    c = Fraction(ceil_div((2*L+M) << C_BITS, K), 1 << C_BITS)
    assert 0 < theta <= c < 1 and c-theta < Fraction(1,1<<C_BITS) < rho/16
    shift = ceil_log_ratio(16*n*odd*K, M)
    delta = Fraction(odd,1 << shift)
    assert rho/(32*n) < delta <= rho/(16*n)
    # The four non-rank terms have total error < 4*(1+up)*(1+low)*2^-T.
    # Each rank correction costs at most 2*(1+up_single)*(1+low_single)
    # times 2^-T before multiplication by delta; at most 3n terms occur.
    error_factor = 4*(1+up)*(1+low) + 6*n*delta*(1+up_single)*(1+low_single)
    # Avoid constructing 2^T. We need error_factor / 2^T < delta/3.
    ratio = 3*error_factor/delta
    error_bits = ceil_log_ratio(ratio.numerator, ratio.denominator)
    assert error_bits < T and shift < 84000
    # T(x) = c-delta*r on incomparable orders; the approximation error is
    # strictly less than delta/3. These endpoints bound ALL v=(K w/2-L)/M.
    vmin = (K*(c-delta*(n+Fraction(1,3)))/2-L)/M
    vmax = (K*(c+delta/3)/2-L)/M
    assert 0 < vmin < vmax < 1
    # Non-rank products use the dyadic paired donors, the rank products use
    # one ungrouped donor of each kind and odd clears their odd denominators.
    # A difference between consecutive dyadic values uses no new precision.
    precision = T+max(C_BITS,shift)+denominator_v2+v2(M)+1
    assert precision+1 < 1 << 25
    value_count = (1 << 166)*(T+1)**16
    required_chunks = value_count*(precision+1)
    assert required_chunks < 1 << 592 < 1 << H
    check_small_binary_embedding()
    print(f'Donor axes: {len(fixed)}; marker prime pairs: {len(pairs)} total, '
          f'{len(eligible)} eligible, {len(chosen)} used.')
    print(f'First and last chosen: {chosen[0]}, {chosen[-1]}.')
    print(f'Integer bit lengths K,L,M: {K.bit_length()},{L.bit_length()},{M.bit_length()}.')
    print(f'Odd denominator bits: {odd.bit_length()}; denominator v2: {denominator_v2}.')
    print(f'delta shift: {shift}; ceiling log2(3*error_factor/delta): {error_bits}.')
    print(f'Precision bound: {precision}; count and required chunk bit lengths: '
          f'{value_count.bit_length()}, {required_chunks.bit_length()}.')
    print('Exact 0<v<1, rho/(32n)<delta<=rho/(16n), and all 420 literal lags checked.')


if __name__ == '__main__':
    if sys.argv[1:] not in ([], ['--excluded']):
        raise SystemExit('usage: ppi_slot_counterexample_check.py [--excluded]')
    main(export_excluded=bool(sys.argv[1:]))

