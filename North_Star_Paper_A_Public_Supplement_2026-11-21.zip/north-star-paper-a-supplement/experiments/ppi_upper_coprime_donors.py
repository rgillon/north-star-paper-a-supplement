"""Exact integer upper interpolation on a tensor of disjoint odd groups.

Each donor places a signed upset on every coatom of its quotient prime
axes. In FIBERS, abs(first entry) is the quotient prime and its sign is
the discrepancy. Bit s of the hexadecimal integer selects hidden shell s.
Its prime factors are the HIDDEN entries indexed by the set bits of s.
Each ZERO_ROWS tuple lists quotient prime indices in one conductor.
Only the Python standard library is needed.
"""
from math import gcd, isqrt, prod


FIRST_HIDDEN = (3, 5, 7, 11, 17)
FIRST_FIBERS = [
    (61, 0x80000000), (-67, 0x80800000), (71, 0x88000000), (-97, 0xaaa80000),
    (101, 0xaaaa8000), (103, 0xaaa8aaa8), (-107, 0xc8800000), (113, 0xc880c080),
    (127, 0xeaa80000), (131, 0xe8c0c080), (-137, 0xeae0eae0), (-139, 0xecccec00),
    (-149, 0xfcecfca8), (-151, 0xfee8fca8),
]
FIRST_ZERO_ROWS = [
    (0, 1, 3, 5), (1, 2, 5, 6),
    (3, 4, 5, 6), (0, 1, 6, 7),
    (1, 4, 5, 10), (1, 2, 3, 5, 8, 10),
    (3, 5, 9, 10), (3, 5, 6, 7, 8, 11),
    (1, 2, 3, 4, 9, 11), (1, 5, 7, 12),
    (0, 1, 3, 4, 6, 8, 9, 12), (1, 2, 3, 7, 9, 13),
    (0, 2, 4, 5, 7, 8, 10, 11, 12, 13),
]


SECOND_HIDDEN = (13, 19, 29, 31, 47)
SECOND_FIBERS = [
    (710641, 0x80008000), (720361, 0x88000000), (734329, 0x80808080), (750121, 0xa000a000),
    (758633, 0xa0a00000), (759001, 0xa8000000), (759709, 0x88808880), (760537, 0x88888880),
    (774661, 0xa8008800), (775097, 0xa0a0a080), (778597, 0xc0c00000), (793717, 0xc0c08000),
    (794221, 0xc0c08080), (799637, 0xa8a08880), (799961, 0xa8a88800), (800483, 0xa8a88888),
    (800801, 0xa8a8a800), (802733, 0xaaa8aa88), (805507, 0xccc00000), (807241, 0xe0008000),
    (816593, 0xe0a00000), (816961, 0xe8000000), (817237, 0xe0c00000), (832217, 0xe0a08080),
    (833057, 0xe0a0a080), (835451, 0xe0e0c0c0), (835531, 0xec00a800), (857737, 0xe8c08800),
    (859003, 0xe8c0c0c0), (859081, 0xe8c0a880), (859267, 0xecc08000), (859667, 0xeca08880),
    (860507, 0xeca0a880), (862319, 0xece0c080), (862987, 0xf8a0f880), (865091, 0xfcc0e080),
    (866081, 0xeeececc8), (866471, 0xfec0e080), (866683, 0xfea8e0a0), (867059, 0xfce0f8e0),
    (867121, 0xfaeae888), (867253, 0xfea8eaa0), (867271, 0xfea8eaa8), (868489, 0xfeeeccc0),
    (868669, 0xfeeae800), (868841, 0xffece0e0), (869203, 0xfee8eaa8), (869233, 0xfeeae8c8),
    (869257, 0xfee8f8c8), (869381, 0xfeecfce0), (-793981, 0xc8008800), (-800029, 0xaa80a080),
    (-800477, 0xa8a0a880), (-800557, 0xaa888880), (-801341, 0xaaa88800), (-801641, 0xaaa8a000),
    (-802777, 0xaaaaa8a8), (-817669, 0xc8808880), (-818341, 0xea000000), (-819061, 0xc8c08080),
    (-821131, 0xccc08080), (-834151, 0xec008000), (-842813, 0xeaa00000), (-859801, 0xe8c0e080),
    (-860513, 0xeca88888), (-860543, 0xe8a8e888), (-860843, 0xeea0a000), (-861139, 0xecc88880),
    (-861761, 0xf8c0a080), (-864793, 0xeeccecc8), (-865357, 0xfeaac000), (-866707, 0xffec8800),
    (-867203, 0xfae8faa8), (-867589, 0xffccf800), (-867887, 0xfce8f8e0), (-868111, 0xffc8fcc0),
    (-868313, 0xffeee000), (-868327, 0xfee0e8a0), (-868529, 0xffe0ece0), (-868531, 0xffe0eec0),
    (-868559, 0xffe0eee0), (-868577, 0xffeec8c8), (-868727, 0xfee8f0e0), (-868739, 0xfeeaf800),
    (-868771, 0xffece080), (-868783, 0xfeeeec00), (-868799, 0xffece0a0), (-868877, 0xffecf800),
    (-868883, 0xfeeefe00), (-868957, 0xffeef0e0), (-869173, 0xfee8e8a8), (-869273, 0xfee8faa8),
    (-869291, 0xfeeaeae8), (-869299, 0xfeeceea0), (-869303, 0xfeeaf8c8), (-869317, 0xfeeceea8),
    (-869369, 0xfeecfea0), (-869371, 0xfeecfcc8), (-869471, 0xffecfac8), (-869707, 0xfffffffa),
]
SECOND_ZERO_ROWS = [
    (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 20, 74, 75, 76, 77, 78, 82, 83, 84, 85, 87, 89, 91, 95, 96, 97, 98), (0, 20, 41, 50, 51, 52),
    (4, 15, 25, 50, 51, 53), (3, 11, 47, 50, 51, 59),
    (7, 26, 29, 50, 51, 67), (2, 30, 40, 50, 51, 71),
    (7, 26, 37, 50, 51, 78), (11, 13, 47, 50, 51, 81),
    (12, 24, 26, 50, 51, 86), (10, 22, 39, 50, 51, 88),
    (5, 15, 26, 50, 52, 53), (7, 16, 42, 50, 52, 61),
    (10, 20, 37, 50, 52, 72), (12, 18, 33, 50, 52, 73),
    (12, 17, 36, 50, 52, 81), (2, 31, 47, 50, 52, 84),
    (7, 25, 41, 50, 52, 85), (4, 25, 48, 50, 52, 88),
    (12, 14, 47, 50, 52, 89), (14, 16, 34, 50, 52, 92),
    (11, 16, 48, 50, 52, 95), (6, 25, 44, 50, 52, 97),
    (3, 12, 48, 50, 53, 59), (12, 14, 44, 50, 53, 76),
    (11, 19, 33, 50, 53, 83), (7, 26, 41, 50, 53, 85),
    (12, 14, 47, 50, 53, 87), (6, 25, 44, 50, 53, 92),
    (12, 15, 46, 50, 53, 96), (3, 10, 49, 50, 54, 56),
    (2, 31, 38, 50, 54, 70), (10, 21, 37, 50, 54, 71),
    (11, 14, 47, 50, 54, 73), (11, 15, 47, 50, 54, 75),
    (6, 25, 43, 50, 54, 77), (11, 16, 49, 50, 54, 81),
    (2, 32, 48, 50, 54, 84), (12, 16, 48, 50, 54, 89),
    (6, 26, 49, 50, 54, 93), (6, 23, 43, 50, 55, 69),
    (12, 13, 40, 50, 55, 70), (11, 17, 39, 50, 55, 74),
    (10, 20, 46, 50, 55, 84), (14, 19, 27, 50, 55, 95),
    (15, 18, 28, 50, 55, 97), (3, 19, 27, 50, 56, 58),
    (4, 25, 49, 50, 56, 71), (12, 15, 48, 50, 56, 72),
    (15, 18, 29, 50, 56, 76), (2, 33, 44, 50, 56, 80),
    (13, 16, 35, 50, 56, 84), (11, 19, 35, 50, 56, 92),
    (16, 23, 24, 50, 56, 95), (2, 46, 48, 50, 57, 67),
    (3, 28, 47, 50, 57, 71), (10, 26, 36, 50, 57, 80),
    (6, 27, 34, 50, 57, 85), (10, 26, 34, 50, 58, 69),
    (11, 21, 47, 50, 58, 73), (10, 26, 36, 50, 58, 74),
    (6, 27, 34, 50, 58, 75), (14, 19, 38, 50, 59, 66),
    (3, 33, 43, 50, 59, 74), (19, 20, 27, 50, 59, 78),
    (18, 22, 29, 50, 59, 85), (19, 22, 27, 50, 59, 90),
    (3, 35, 40, 50, 59, 92), (3, 34, 47, 50, 59, 93),
    (18, 22, 31, 50, 59, 96), (13, 22, 29, 50, 60, 66),
    (13, 20, 37, 50, 60, 73), (4, 27, 42, 50, 60, 78),
    (11, 23, 27, 50, 60, 80), (13, 21, 41, 50, 60, 83),
    (13, 22, 40, 50, 60, 88), (15, 22, 38, 50, 60, 92),
    (3, 35, 46, 50, 60, 94), (4, 30, 38, 50, 60, 98),
    (7, 30, 45, 50, 61, 64), (12, 25, 28, 50, 61, 65),
    (16, 26, 28, 50, 61, 72), (7, 41, 44, 50, 61, 77),
    (5, 43, 49, 50, 61, 83), (5, 44, 47, 50, 61, 84),
    (8, 30, 34, 50, 61, 85), (6, 43, 47, 50, 61, 93),
    (9, 31, 47, 50, 62, 72), (17, 26, 39, 50, 62, 78),
    (16, 26, 47, 50, 62, 84), (9, 33, 44, 50, 62, 92),
    (10, 39, 44, 50, 63, 65), (12, 28, 33, 50, 63, 68),
    (16, 30, 34, 50, 63, 91), (10, 39, 49, 50, 64, 65),
    (16, 30, 34, 50, 65, 79), (17, 31, 36, 50, 69, 99),
    (11, 35, 48, 50, 70, 82), (3, 16, 41, 51, 52, 57),
    (1, 29, 32, 52, 58, 60),
]


def is_prime(p):
    return p > 1 and all(p % k for k in range(2, isqrt(p) + 1))


def echelon(matrix):
    """Bareiss elimination of a square or singly augmented integer matrix."""
    rows = [row.copy() for row in matrix]
    n = len(rows)
    previous = sign = 1
    for j in range(n - 1):
        i = next(i for i in range(j, n) if rows[i][j])
        if i != j:
            rows[i], rows[j] = rows[j], rows[i]
            sign = -sign
        pivot = rows[j][j]
        for i in range(j + 1, n):
            factor = rows[i][j]
            for k in range(j + 1, len(rows[i])):
                value = pivot * rows[i][k] - factor * rows[j][k]
                assert value % previous == 0
                rows[i][k] = value // previous
            rows[i][j] = 0
        previous = pivot
    return sign * rows[-1][n - 1], rows


def donor(hidden, fibers, spectral, scale, expected_det):
    primes = [abs(c) for c, _ in fibers]
    signs = [1 if c > 0 else -1 for c, _ in fibers]
    count = len(fibers)
    assert len(set(primes + list(hidden))) == count + len(hidden)
    assert all(is_prime(p) for p in primes + list(hidden))
    assert sum(signs) == 0
    states = range(1 << len(hidden))
    weights = [prod(p - 1 for i, p in enumerate(hidden) if mask >> i & 1)
               for mask in states]
    for p, (_, bits) in zip(primes, fibers):
        shells = [s for s in states if bits >> s & 1]
        assert bits < 1 << len(weights)
        assert sum(weights[s] for s in shells) == scale * (p - 1)
        assert all(bits >> t & 1 for s in shells for t in states if t & s == s)
    for conductor in spectral:
        assert len(set(conductor)) == len(conductor)
        assert all(0 <= i < count for i in conductor)
        assert sum(fibers[i][0] for i in conductor) == 0

    # At a quotient generator the coefficient of its individual Ramanujan
    # row has value alpha. On coatom i it is unchanged if i is absent and
    # otherwise multiplied by 1-p_i. The target is 0 at top, 1 at coatoms.
    matrix = [[int(i in c) for c in spectral] for i in range(count)]
    assert len(spectral) == count - 1
    determinant, _ = echelon(matrix[:-1])
    assert determinant == expected_det
    denominator = abs(determinant) * prod(primes)
    targets = [-denominator // p for p in primes]
    _, triangular = echelon([row + [v] for row, v in zip(matrix[:-1], targets)])
    alpha = [0] * (count - 1)
    for j in reversed(range(len(alpha))):
        z = triangular[j][-1] - sum(triangular[j][i] * alpha[i]
                                    for i in range(j + 1, len(alpha)))
        assert z % triangular[j][j] == 0
        alpha[j] = z // triangular[j][j]
    root = -sum(alpha)
    assert root + sum(alpha) == 0
    for row, p in zip(matrix, primes):
        assert root + sum(a * (1 - p * entry) for a, entry in zip(alpha, row)) == denominator
    return denominator


def bezout(a, b):
    r, s, oldr, olds = 0, 1, 1, 0
    while b:
        q, remainder = divmod(a, b)
        a, b = b, remainder
        oldr, r = r, oldr - q * r
        olds, s = s, olds - q * s
    return a, oldr, olds


def main():
    all_axes = list(FIRST_HIDDEN + SECOND_HIDDEN) + [
        abs(p) for p, _ in FIRST_FIBERS + SECOND_FIBERS]
    assert len(all_axes) == len(set(all_axes)) == 124
    d1 = donor(FIRST_HIDDEN, FIRST_FIBERS, FIRST_ZERO_ROWS, 128, 151)
    d2 = donor(SECOND_HIDDEN, SECOND_FIBERS, SECOND_ZERO_ROWS, 12, -500951232)
    assert gcd(d1, d2) == 1
    g, a, b = bezout(d1, d2)
    assert g == 1 and a * d1 + b * d2 == 1
    # The integer witnesses from donor() are d_i w_i.  Writing P_i=|e_i|,
    # a (d1 w1) tensor P2 + b P1 tensor (d2 w2) has integer entries,
    # zero product with the spectrum of e1 tensor e2 and equals P1 tensor P2
    # throughout the product of the two upper sets.
    print("Verified 124 disjoint prime axes and exact scaled upper witnesses.")
    print("Signed incidence determinants: 151 and -500951232.")
    print("GCD of integer scaling factors:", g)


if __name__ == "__main__":
    main()

