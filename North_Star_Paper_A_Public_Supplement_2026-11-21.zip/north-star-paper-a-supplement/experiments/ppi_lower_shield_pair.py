"""Exact two-shield certificate for dyadic lower interpolation, using library Python."""
from fractions import Fraction
from math import gcd, isqrt, lcm, prod

# Each signed integer c describes one signed shell of order abs(c).
CASES = [
    ([23,37,41,-43,59,-89,-157,-163,-181,-191,223,-241,-251,271,277,307,-311,389],
     [145921,12297,154123,15372,252429,76815,219158,135706,227868,34849,13858,
      129058,201785,227393,36432,208513,205569]),
    ([509,563,569,-719,797,863,-1187,-1319,-1367,-1913,-2039,-2273,4073,
      4157,4787,-4793,5417,-7433,7529,-9587,-9743,-10103,11273,11939],
     [9581838,14402644,9156180,9688835,10879461,10280098,616929,6390353,
      9487092,7621035,1417681,15772084,10629916,16722364,6654,9057209,
      11042062,9930354,16721326,14844957,7827120,8951834,13873096]),
]

def solve_incidence(ps, masks):
    # Variables are the spectral contributions at identity. Use exact pivots.
    n = len(masks)
    rows = [[Fraction((m >> i) & 1) for m in masks]+[Fraction(1-p,p)]
            for i,p in enumerate(ps)]
    assert len(ps) == n+1
    for j in range(n):
        pivot = next(i for i in range(j,len(rows)) if rows[i][j])
        rows[pivot],rows[j]=rows[j],rows[pivot]
        scale = rows[j][j]
        rows[j] = [v/scale for v in rows[j]]
        for i,row in enumerate(rows):
            if i != j:
                k = row[j]
                rows[i] = [a-k*b for a,b in zip(row,rows[j])]
    assert not any(rows[n])
    return [rows[j][-1] for j in range(n)]

def inspect(c, masks):
    ps = list(map(abs,c))
    assert len(set(ps)) == len(ps)
    assert all(p>2 and all(p%d for d in range(2,isqrt(p)+1)) for p in ps)
    signs = [n//p for n,p in zip(c,ps)]
    assert sum(s*(p-1) for s,p in zip(signs,ps)) == 0
    for m in masks:
        assert sum(s*(-1 if m>>i&1 else p-1) for i,(s,p) in enumerate(zip(signs,ps))) == 0
    alpha = solve_incidence(ps,masks)
    root = -sum(alpha)
    for i,p in enumerate(ps):
        # Normalized primitive Ramanujan sum is 1 at zero and -1/(p-1) elsewhere.
        assert root+sum(a*(Fraction(-1,p-1) if m>>i&1 else 1)
                        for a,m in zip(alpha,masks)) == 1
    assert root + sum(alpha) == 0
    # Each arbitrary-order value of a single normalized packet has denominator
    # dividing product_(i in mask) (p_i-1). This includes all 2**len(ps) values.
    full_denom = lcm(root.denominator,
                     *(a.denominator*prod(p-1 for i,p in enumerate(ps) if m>>i&1)
                       for a,m in zip(alpha,masks)))
    return full_denom, abs(root)+sum(map(abs,alpha))

def main():
    (d1,b1),(d2,b2) = [inspect(c,masks) for c,masks in CASES]
    assert gcd(prod(abs(c) for c in CASES[0][0]),prod(abs(c) for c in CASES[1][0])) == 1
    f1,f2=d1//(d1&-d1), d2//(d2&-d2)
    assert gcd(f1,f2)==1
    # k v1 P2 +(1-k) P1 v2 has only dyadic denominators and agrees with P1 P2
    # on the whole product lower set. These congruences certify every value.
    k=f1*pow(f1,-1,f2)
    assert k%f1==0 and (1-k)%f2==0
    print('denominator 2-adic valuations', *( (d&-d).bit_length()-1 for d in (d1,d2)))
    print('odd denominator bounds', f1, f2)
    print('Bezout coefficient',k)
    bound=abs(k)*b1+abs(1-k)*b2
    print('dyadic lower sup bound < 2^', (bound.numerator//bound.denominator).bit_length(), sep='')

if __name__=='__main__':main()

