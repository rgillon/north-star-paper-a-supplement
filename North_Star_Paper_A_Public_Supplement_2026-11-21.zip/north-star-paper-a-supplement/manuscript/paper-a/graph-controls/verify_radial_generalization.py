#!/usr/bin/env python3
"""Exhaustive exact test of stronger radial-binary P004 sign classification.
All radial Boolean profiles, not restricted to subgroup unions, are visited.
Direct bitset cyclic autocorrelations validate conductor-square class membership.
"""
import json, math, time, collections
from pathlib import Path
from verify_p004 import setup, spec, inverse_profile, actual_membership, correlation, factor

def radial_graph(F,fa,vs,ix):
    vertices=[i for i,val in enumerate(F) if val]
    parent={i:i for i in vertices}
    def root(i):
        while i!=parent[i]:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    def link(i,j):
        u,v=root(i),root(j)
        if u!=v:parent[v]=u
    edges=[]
    for i,s in enumerate(vs):
        if not F[i]:continue
        for k,(p,a) in enumerate(fa):
            if s[k]==a:continue
            new=list(s);new[k]+=1;j=ix[tuple(new)]
            if F[j] and (2*F[i])%p**(a-s[k]):link(i,j);edges.append((i,j))
    comps=collections.defaultdict(list)
    for i in vertices:comps[root(i)].append(i)
    rootix=ix[(0,)*len(fa)]
    free=[tuple(c) for c in comps.values() if rootix not in c]
    return free,comps,edges

def check(n):
    start=time.monotonic()
    fa,vs,ix,contain,W,phi=setup(n)
    signatures=collections.defaultdict(list)
    corrs={}
    free_hist=collections.Counter()
    total_flip_instances=0
    zero_count=0
    witness=None
    for mask in range(1<<len(vs)):
        if mask==0:continue
        F=spec(mask,fa,vs,ix,W)
        assert F[0] > 0
        pure=[i for i,s in enumerate(vs) if sum(z>0 for z in s)<=1]
        free,comps,edges=radial_graph(F,fa,vs,ix)
        free_hist[len(free)]+=1
        signatures[tuple(x*x for x in F)].append(mask)
        bits=actual_membership(n,fa,vs,ix,[(mask>>i)&1 for i in range(len(vs))])
        corr=correlation(bits,n)
        assert corr[0]==F[0]
        prev=corrs.get(tuple(x*x for x in F))
        if prev is not None:assert prev==corr
        else:corrs[tuple(x*x for x in F)]=corr
        zero_count+=sum(v==0 for v in F)
        # Exact arithmetic inverse and full cyclic autocorrelation for every component choice
        seen=set()
        for choice in range(1<<len(free)):
            G=list(F)
            for j,c in enumerate(free):
                if choice>>j&1:
                    for k in c:G[k]=-G[k]
            inv=inverse_profile(G,fa,vs,ix,W)
            assert inv is not None and all(x in (0,1) for x in inv),(n,mask,choice,G,inv)
            mate=sum(x<<i for i,x in enumerate(inv))
            assert mate not in seen
            seen.add(mate)
            assert spec(mate,fa,vs,ix,W)==tuple(G)
            mate_bits=actual_membership(n,fa,vs,ix,inv)
            assert correlation(mate_bits,n)==corr,(n,mask,choice)
            total_flip_instances+=1
        if len(free) and witness is None:
            witness={"original_profile_bits":mask,"free_components":[[math.prod(p**s for (p,a),s in zip(fa,vs[k])) for k in c] for c in free],"mates":len(seen)}
    reverse={corr:sig for sig,corr in corrs.items()}
    assert len(reverse)==len(signatures)
    for sig,masks in signatures.items():
        f=spec(masks[0],fa,vs,ix,W)
        free,_,_=radial_graph(f,fa,vs,ix)
        assert len(masks)==(1<<len(free)),(n, sig, masks,free)
    return {"N":n,"factors":fa,"radial_binary_sets_including_empty":1<<len(vs),"nonempty_radial_binary_sets":(1<<len(vs))-1,"spectral_classes":len(signatures),"nontrivial_spectral_classes":sum(len(v)>1 for v in signatures.values()),"max_free_components":max(free_hist),"free_component_histogram":dict(free_hist),"total_component_flip_instances_checked":total_flip_instances,"zero_conductor_coefficients":zero_count,"full_autocorrelation_independently_checked":True,"first_free_component_witness":witness,"seconds":round(time.monotonic()-start,3)}
if __name__=='__main__':
    result=[check(n) for n in [1,2,6,12,18,36,60]]
    with open(Path(__file__).with_name('radial_results.json'),'w') as f:json.dump(result,f,indent=2)
    print(json.dumps(result,indent=2))
