#!/usr/bin/env python3
"""Independent exhaustive subgroup-union sign-graph audit, exact integers.

Efficiently enumerates all increasing 0/1 profiles on prime valuation lattices.
A numba-compiled depth-first search tracks conductor Fourier coefficients exactly
using the product-of-prime-power Ramanujan shell-sum matrix. Only full monotone
profiles are checked. Every unanchored component is recorded as a failure.

This script does not establish universal subgroup-union rigidity.
"""
import argparse
import itertools
import json
import math
from pathlib import Path
import time
import numpy as np
from numba import njit

DEFAULT_MODULI = [1440,2160,2310,2520,3200,3600,4620,5040,6272,6480,10800,11664,15552,20000,20736,21600,28224,46656,279936,2**9*3**9]


def factor(n):
    out=[]
    p=2
    while p*p<=n:
        if n%p ==0:
            a=0
            while n%p==0:n//=p;a+=1
            out.append((p,a))
        p+=1 if p==2 else 2
    if n>1:out.append((n,1))
    return out


def prepare(n):
    fa=factor(n)
    vals=list(itertools.product(*(range(a+1) for p,a in fa)))
    vals.sort(key=lambda v:(sum(v),v))
    ix={v:i for i,v in enumerate(vals)}
    L=len(vals)
    parent=np.full((L,len(fa)),-1,dtype=np.int32)
    for j,v in enumerate(vals):
        for i,x in enumerate(v):
            if x:
                u=list(v);u[i]-=1
                parent[j,i]=ix[tuple(u)]
    M=np.ones((L,L),dtype=np.int64)
    for si,s in enumerate(vals):
        for ri,r in enumerate(vals):
            z=1
            for (p,a),sk,rk in zip(fa,s,r):
                if rk==a: continue
                if sk<=rk:z *= (p-1)*p**(a-rk-1)
                elif sk==rk+1:z *= -p**(a-rk-1)
                else:z=0;break
            M[si,ri]=z
    root=ix[tuple(0 for p,a in fa)]
    anchor=np.array([sum(vv>0 for vv in v)<=1 for v in vals],dtype=np.bool_)
    lower=[]; upper=[]; mod=[]
    for li,v in enumerate(vals):
        for i,(p,a) in enumerate(fa):
            if v[i]<a:
                u=list(v);u[i]+=1
                lower.append(li)
                upper.append(ix[tuple(u)])
                mod.append(p**(a-v[i]))
    return fa,vals,parent,M,np.array(lower,np.int32),np.array(upper,np.int32),np.array(mod,np.int64),anchor

@njit(cache=True)
def inspect(F, lower, upper, modulo, anchor):
    L=len(F)
    dsu=np.arange(L,dtype=np.int32)
    anchored=np.zeros(L,dtype=np.bool_)
    active=0
    for i in range(L):
        if F[i]!=0:
            active += 1
            anchored[i]=anchor[i]
    if active==0:
        return 0
    for e in range(len(lower)):
        lo=lower[e]; hi=upper[e]
        if F[lo]!=0 and F[hi]!=0 and (2*F[lo])%modulo[e] !=0:
            a=lo;b=hi
            while dsu[a]!=a:
                dsu[a]=dsu[dsu[a]];a=dsu[a]
            while dsu[b]!=b:
                dsu[b]=dsu[dsu[b]];b=dsu[b]
            if a!=b:
                dsu[b]=a
                anchored[a]=anchored[a] or anchored[b]
    for i in range(L):
        if F[i]!=0:
            a=i
            while dsu[a]!=a:
                dsu[a]=dsu[dsu[a]];a=dsu[a]
            if not anchored[a]:return 1
    return 0

@njit(cache=True)
def walk(j,profile,F,parent,M,lower,upper,modulo,anchor,counters):
    if j==len(profile):
        counters[0]+=1
        if inspect(F,lower,upper,modulo,anchor):
            counters[1]+=1
        return
    forced=False
    for k in range(parent.shape[1]):
        i=parent[j,k]
        if i>=0 and profile[i]:
            forced=True
            break
    if not forced:
        profile[j]=0
        walk(j+1,profile,F,parent,M,lower,upper,modulo,anchor,counters)
    profile[j]=1
    for i in range(len(F)): F[i]+=M[i,j]
    walk(j+1,profile,F,parent,M,lower,upper,modulo,anchor,counters)
    for i in range(len(F)): F[i]-=M[i,j]
    profile[j]=0


def run_one(n):
    fa,vs,parent,M,lower,upper,modulo,anchor=prepare(n)
    start=time.perf_counter()
    counters=np.zeros(2,dtype=np.int64)
    profile=np.zeros(len(vs),dtype=np.int8)
    F=np.zeros(len(vs),dtype=np.int64)
    walk(0,profile,F,parent,M,lower,upper,modulo,anchor,counters)
    return {'modulus':n,'factors':fa,'valuation_cells':len(vs),'subgroup_unions_including_empty':int(counters[0]),'unanchored_targets':int(counters[1]),'elapsed_seconds':round(time.perf_counter()-start,3)}


def selftest():
    from verify_p004 import setup, spec
    for n in [1,2,6,12,36,60,210,420,756]:
        fa,vs,parent,M,lower,upper,modulo,anchor=prepare(n)
        f2,v2,ix,contain,W,phi=setup(n)
        assert vs==v2
        for bit in range(len(vs)):
            F=tuple(int(x) for x in M[:,bit])
            target=spec(1<<bit,fa,vs,ix,W)
            assert F==target, (n,bit,F,target)
        r=run_one(n)
        print('selftest',n,r['subgroup_unions_including_empty'],r['unanchored_targets'],flush=True)
        official={int(k['N']):k['sets'] for k in json.load(open(Path(__file__).with_name('computation_results.json')))}
        assert r['subgroup_unions_including_empty']==official[n], (n,r,official[n])
        assert not r['unanchored_targets']


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--selftest',action='store_true')
    ap.add_argument('--moduli',nargs='*',type=int,default=DEFAULT_MODULI)
    ap.add_argument('--output',default=str(Path(__file__).with_name('extended_subgroup_results.json')))
    args=ap.parse_args()
    if args.selftest:selftest()
    results=[]
    for n in args.moduli:
        r=run_one(n)
        results.append(r)
        print(r,flush=True)
        Path(args.output).write_text(json.dumps({'description':'Exact integer profile-based sign graph audit; includes empty set in each modulus','moduli':results,'totals':{'subgroup_unions_including_empty':sum(x['subgroup_unions_including_empty'] for x in results),'unanchored_targets':sum(x['unanchored_targets'] for x in results)}},indent=2)+'\n')
    print('TOTAL',sum(x['subgroup_unions_including_empty'] for x in results),flush=True)
