#!/usr/bin/env python3
"""Exact validation of symmetry-reduced radial homometry and examples.
Checks graph sign masks, least periods, translations and complements, and actual
orbits of every radial homometry class for the listed moduli. No FFT is used.
"""
from collections import defaultdict
from math import gcd
from verify_p004 import setup,spec,actual_membership,correlation
from verify_radial_generalization import radial_graph


def v2(n):
    if not n: return 0
    a=0
    while n%2==0: a+=1;n//=2
    return a

def run(N):
    fa,vs,ix,contain,W,phi=setup(N)
    spec_cls=defaultdict(list)
    val={}
    for mask in range(1,1<<len(vs)):
        F=spec(mask,fa,vs,ix,W)
        pts=tuple(x for x in range(N) if actual_membership(N,fa,vs,ix,[(mask>>i)&1 for i in range(len(vs))])>>x&1)
        assert correlation(sum(1<<x for x in pts),N)[0]==len(pts)
        spec_cls[tuple(x*x for x in F)].append(mask)
        val[mask]=(F,frozenset(pts))
    tested=0
    for sig,masks in spec_cls.items():
        mask=masks[0];F,A=val[mask];k=len(A)
        free,comps,_=radial_graph(F,fa,vs,ix)
        u=len(free)
        assert len(masks)==1<<u
        ds=[d for d in range(1,N+1) if N%d==0 and {(x+d)%N for x in A}==A]
        d=min(ds)
        # Every radial mate has same least period.
        assert all(min(z for z in ds if {(x+z)%N for x in val[m][1]}==val[m][1])==d for m in masks)
        Tmask=set()
        if d%2==0:
            for j,comp in enumerate(free):
                conductors=[1]
                conductors=[__import__('math').prod(p**vs[i][k] for k,(p,a) in enumerate(fa)) for i in comp]
                target=[v2(c)==v2(d) for c in conductors]
                assert all(target) or not any(target)
                if all(target): Tmask.add(j)
            assert Tmask
        # The radial translates must be exactly the nontrivial half-period translation, if any.
        for m in masks:
            B=val[m][1]
            radial_translates=[t for t in range(N) if any({(x+t)%N for x in B}==val[j][1] for j in masks)]
            expected=[t for t in range(N) if t%d==0 or (d%2==0 and t%d==d//2)]
            assert radial_translates==expected,(N,d,radial_translates,expected)
        allmask=set(range(u)) if k*2==N else set()
        rank=int(bool(Tmask))+int(bool(allmask) and allmask!=Tmask)
        predicted=(1<<u)//(1<<rank)
        remaining=set(masks);orbits=0
        while remaining:
            m=next(iter(remaining));B=val[m][1]
            orbit=set()
            for t in range(N):
                trans={(x+t)%N for x in B}
                orbit.update(j for j in masks if val[j][1]==trans)
                if 2*k==N:
                    co=frozenset(set(range(N))-trans)
                    orbit.update(j for j in masks if val[j][1]==co)
            assert orbit<=remaining
            remaining-=orbit;orbits+=1
        assert orbits==predicted,(N,d,u,orbits,predicted)
        tested+=1
    return N,len(spec_cls),tested

if __name__=='__main__':
    for n in (2,6,12,18,24,36,60):print('symmetry orbit check OK',run(n))
    A={0,6,8,12,16,18};B={2,8,10,14,16,22};N=24
    C=lambda S:tuple(sum(((x+t)%N in S) for x in S) for t in range(N))
    assert C(A)==C(B)
    assert not any({(x+t)%N for x in A}==B for t in range(N))
    print('N=24 non-dihedral witness: verified exact autocorrelation')
