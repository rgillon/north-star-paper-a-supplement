#!/usr/bin/env python3
"""Independent exact-arithmetic verification of the P004 sign-graph criterion.
No external numerical FFT or pre-existing North Star program is used.
"""
import math, itertools, json, collections, argparse, time
from pathlib import Path


def factor(n):
    x=n; out=[]; p=2
    while p*p<=x:
        if x%p==0:
            a=0
            while x%p==0: x//=p; a+=1
            out.append((p,a))
        p+=1
    if x>1:out.append((x,1))
    return out

def setup(n):
    fa=factor(n); vs=list(itertools.product(*(range(a+1) for p,a in fa)))
    vs.sort(key=lambda v:(sum(v),v)); ix={v:i for i,v in enumerate(vs)}
    contain=[]
    for r in vs:
        contain.append(sum(1<<i for i,v in enumerate(vs) if all(x>=y for x,y in zip(v,r))))
    W=[math.prod(p**(a-r) for (p,a),r in zip(fa,v)) for v in vs]
    phi=[math.prod((p-1)*p**(s-1) if s else 1 for (p,a),s in zip(fa,v)) for v in vs]
    return fa,vs,ix,contain,W,phi

def upsets(contain):
    # Adding principal upsets and deduplicating yields every monotone Boolean profile.
    seen={0}; stack=[0]
    while stack:
        mask=stack.pop()
        yield mask
        for c in contain:
            m=mask|c
            if m not in seen:
                seen.add(m);stack.append(m)

def alpha_transform(mask, fa,vs,ix):
    alpha=[]
    for r in vs:
        s=0
        active=[i for i,x in enumerate(r) if x>0]
        for z in range(1<<len(active)):
            rv=list(r)
            for j,i in enumerate(active):
                if z>>j &1:rv[i]-=1
            sign=(-1)**z.bit_count()
            s+=sign*((mask>>ix[tuple(rv)])&1)
        alpha.append(s)
    return alpha

def spec(mask,fa,vs,ix,W):
    aa=alpha_transform(mask,fa,vs,ix)
    return tuple(sum(W[i]*aa[i] for i,r in enumerate(vs) if all(v>=s for v,s in zip(r,t))) for t in vs)

def graph(F,fa,vs,ix):
    verts={i for i,f in enumerate(F) if f}
    parent={i:i for i in verts}
    def find(i):
        while i!=parent[i]:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    def union(i,j):
        a=find(i);b=find(j)
        if a!=b:parent[b]=a
    edges=[]
    for i,s in enumerate(vs):
        if i not in verts: continue
        for k,(p,a) in enumerate(fa):
            if s[k]==a:continue
            t=list(s);t[k]+=1;j=ix[tuple(t)]
            if j in verts and (2*F[i])%(p**(a-s[k]))!=0:
                union(i,j);edges.append((i,j))
    comps=collections.defaultdict(list)
    for i in verts:comps[find(i)].append(i)
    def anchored(v):return sum(x>0 for x in v)<=1
    free=[tuple(m) for m in comps.values() if not any(anchored(vs[i]) for i in m)]
    return edges,list(comps.values()),free

def inverse_profile(G,fa,vs,ix,W):
    al=[]
    for r,w in zip(vs,W):
        numerator=0
        active=[i for i,((p,a),val) in enumerate(zip(fa,r)) if val<a]
        for z in range(1<<len(active)):
            t=list(r)
            for j,i in enumerate(active):
                if z>>j&1:t[i]+=1
            numerator+=(-1)**z.bit_count()*G[ix[tuple(t)]]
        if numerator%w: return None
        al.append(numerator//w)
    vals=[sum(al[i] for i,t in enumerate(vs) if all(t0<=v0 for t0,v0 in zip(t,v))) for v in vs]
    return vals

def actual_membership(n,fa,vs,ix,profile):
    xmask=0
    for x in range(n):
        v=[]
        for p,a in fa:
            h=0;t=x
            if t==0:h=a
            else:
                while h<a and t%p==0: h+=1;t//=p
            v.append(h)
        if profile[ix[tuple(v)]]:xmask|=1<<x
    return xmask

def correlation(xmask,n):
    full=(1<<n)-1
    return tuple((xmask & (((xmask>>t)|(xmask<<(n-t)))&full)).bit_count() for t in range(n))

def audit(n, full_autocor=True):
    start=time.monotonic();fa,vs,ix,contain,W,phi=setup(n)
    counts=collections.Counter(); maxcomp=0; free_targets=0; free_components=0
    sigmap=collections.defaultdict(list); example=None; firstgraph=None; nontriv=None
    for mask in upsets(contain):
        counts['sets']+=1
        if not mask:continue
        F=spec(mask,fa,vs,ix,W); edges,comps,free=graph(F,fa,vs,ix)
        maxcomp=max(maxcomp,len(comps))
        counts['zero_fourier']+=sum(f==0 for f in F)
        counts['graph_edges']+=len(edges)
        sigmap[tuple(x*x for x in F)].append(mask)
        if free:free_targets+=1;free_components+=len(free)
        if firstgraph is None and len(edges)>0 and len(comps)>1: firstgraph=(mask,F,edges,comps,free)
        # Verify adjacent congruences, pure prime coefficient positivity and no spectral-integrality holes.
        assert F[ix[(0,)*len(fa)]]==sum(math.prod((p-1)*p**(a-r-1) if r<a else 1 for (p,a),r in zip(fa,v)) for i,v in enumerate(vs) if mask>>i&1)
        for i,s in enumerate(vs):
            if sum(z>0 for z in s)<=1:assert F[i]>=0
            for k,(p,a) in enumerate(fa):
                if s[k]<a:
                    t=list(s);t[k]+=1
                    assert (F[i]-F[ix[tuple(t)]])%p**(a-s[k])==0
        if free:
            for select in range(1<<len(free)):
                G=list(F)
                for j,c in enumerate(free):
                    if select>>j&1:
                        for k in c:G[k]=-G[k]
                vals=inverse_profile(G,fa,vs,ix,W)
                assert vals is not None and all(z in (0,1) for z in vals)
                assert all(not vals[i] or all(vals[j] for j,t in enumerate(vs) if all(b>=a for a,b in zip(vs[i],t))) for i in range(len(vs)))
                mk=sum(z<<i for i,z in enumerate(vals))
                assert spec(mk,fa,vs,ix,W)==tuple(G)
        if not example and n==12 and mask: example=(mask,F,edges,comps,free)
    collisions={k:v for k,v in sigmap.items() if len(v)>1}
    for signature,masks in sigmap.items():
        m=masks[0];F=spec(m,fa,vs,ix,W); free=graph(F,fa,vs,ix)[2]
        assert len(masks)==2**len(free), (n,len(masks),len(free),masks[:4])
    counts['spectral_classes_nonempty']=len(sigmap)
    counts['homometric_classes_nontrivial']=len(collisions)
    counts['unanchored_targets']=free_targets
    counts['unanchored_components_total']=free_components
    counts['maximum_graph_components']=maxcomp
    if full_autocor:
        corr_seen={}
        for signature,masks in sigmap.items():
            for mask in masks:
                prof=[(mask>>i)&1 for i in range(len(vs))]
                actual=actual_membership(n,fa,vs,ix,prof)
                corr=correlation(actual,n)
                if signature in corr_seen:assert corr==corr_seen[signature]
                else:corr_seen[signature]=corr
        # For finite cyclic sets any symmetric complete correlation identifies magnitudes:
        # classes cannot collide in their autocorrelations unless signatures match.
        reverse={v:k for k,v in corr_seen.items()}
        assert len(reverse)==len(sigmap)
    counts['direct_autocor_full_per_nonempty_set']=full_autocor
    counts['time_seconds']=round(time.monotonic()-start,3)
    if firstgraph:
        mask,F,edges,comps,free=firstgraph
        counts['graph_example']={'canonical_min_vectors':[list(vs[i]) for i in range(len(vs)) if (mask>>i&1) and all(not (mask>>j&1) or not all(x<=y for x,y in zip(vs[j],vs[i])) or j==i for j in range(len(vs)))], 'conductors':[math.prod(p**e for (p,a),e in zip(fa,s)) for s in vs], 'Fourier_marks':list(F),'edges_conductor_pairs':[[math.prod(p**e for (p,a),e in zip(fa,vs[i])),math.prod(p**e for (p,a),e in zip(fa,vs[j]))] for i,j in edges]}
    return dict(N=n,factors=fa,**counts)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--moduli',nargs='*',type=int,default=[1,2,3,4,6,8,12,18,30,36,60,84,120,180,210,252,420,756]);ap.add_argument('--direct-limit',type=int,default=756)
    a=ap.parse_args(); results=[]
    for n in a.moduli:
        r=audit(n,n<=a.direct_limit);results.append(r)
        print('N',n,'sets',r['sets'],'unanchored',r['unanchored_targets'],'homometric classes',r['homometric_classes_nontrivial'],'full autocor',r['direct_autocor_full_per_nonempty_set'],'elapsed',r['time_seconds'],flush=True)
    with open(Path(__file__).with_name('computation_results.json'),'w') as f:json.dump(results,f,indent=2)
