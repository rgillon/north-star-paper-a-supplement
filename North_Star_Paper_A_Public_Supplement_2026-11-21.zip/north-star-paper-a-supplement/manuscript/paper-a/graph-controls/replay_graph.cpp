// Exact independent replay of the finite graph counts. Compile with C++17.
// For each input N print: N, number of ideals including empty, targets with a free component.
#include <algorithm>
#include <cstdio>
#include <numeric>
#include <stdexcept>
#include <vector>
using std::vector;

struct Edge { int lower, upper, modulus; };

class Audit {
    int n;
    vector<int> divisors, primes, coefficients, parent;
    vector<vector<int>> predecessor, shell_marks;
    vector<Edge> edges;
    vector<bool> chosen, anchor;
    int root(int a) {
        while (a != parent[a]) {
            parent[a] = parent[parent[a]];
            a = parent[a];
        }
        return a;
    }
    int index(int d) const {
        return int(std::lower_bound(divisors.begin(),divisors.end(),d)-divisors.begin());
    }
    void inspect() {
        ++profiles;
        if (coefficients[0]==0) return;
        std::iota(parent.begin(),parent.end(),0);
        for (auto edge : edges) {
            if (2*coefficients[edge.lower] % edge.modulus) {
                parent[root(edge.upper)] = root(edge.lower);
            }
        }
        vector<bool> fixed(divisors.size(),false);
        for (unsigned i=0;i<divisors.size();++i) {
            if (coefficients[i] && anchor[i]) fixed[root(i)]=true;
        }
        for (unsigned i=0;i<divisors.size();++i) {
            if (coefficients[i] && !fixed[root(i)]) { ++unanchored; return; }
        }
    }
    void enumerate(unsigned i) {
        if (i==divisors.size()) { inspect(); return; }
        enumerate(i+1);
        for (int lower : predecessor[i]) if (!chosen[lower]) return;
        chosen[i]=true;
        for (unsigned j=0;j<divisors.size();++j) coefficients[j]+=shell_marks[i][j];
        enumerate(i+1);
        for (unsigned j=0;j<divisors.size();++j) coefficients[j]-=shell_marks[i][j];
        chosen[i]=false;
    }
public:
    int profiles=0, unanchored=0;
    explicit Audit(int order): n(order) {
        int remaining=n;
        for (int p=2;p<=remaining/p;++p) {
            if (remaining%p) continue;
            primes.push_back(p);
            while (remaining%p==0) remaining/=p;
        }
        if (remaining>1) primes.push_back(remaining);
        for (int d=1;d<=n/d;++d) if (n%d==0) {
            divisors.push_back(d); if (d!=n/d) divisors.push_back(n/d);
        }
        std::sort(divisors.begin(),divisors.end());
        int count=int(divisors.size()); chosen.resize(count);
        coefficients.resize(count); parent.resize(count); predecessor.resize(count);
        for (int i=0;i<count;++i) {
            int d=divisors[i],species=0;
            for (int p : primes) {
                if (d%p==0) { predecessor[i].push_back(index(d/p)); ++species; }
                int rest=n/d, power=1;
                while (rest%p==0) { rest/=p; power*=p; }
                if (power>1) edges.push_back({i,index(d*p),power});
            }
            anchor.push_back(species<=1);
            vector<int> row;
            for (int c : divisors) {
                int k=n/c,mark=1;
                for (int p : primes) {
                    int power=1;
                    while ((d/power)%p==0) power*=p;
                    if (power==1) continue;
                    if (k%power==0) mark*=power-power/p;
                    else if (k%(power/p)==0) mark*=-power/p;
                    else { mark=0; break; }
                }
                row.push_back(mark);
            }
            shell_marks.push_back(row);
        }
        enumerate(0);
    }
};

int main() {
    int n;
    while (std::scanf("%d",&n)==1) {
        if (n<=0 || n>10077696) throw std::invalid_argument("order outside recorded audit");
        Audit a(n);
        std::printf("%d %d %d\n",n,a.profiles,a.unanchored);
    }
}
