#!/usr/bin/env python3
"""Independent crosschecks between the older finite-difference implementation
and the new shell-sum implementation on deterministic randomly generated upsets.
"""
import random
from pathlib import Path
import numpy as np
from verify_p004 import setup, spec, graph
from verify_extended_subgroups import prepare, inspect, DEFAULT_MODULI

def run():
    rng=random.Random(20261106)
    checks=0
    for n in DEFAULT_MODULI + [1,2,6,12,36,60,210,420,756]:
        fa,vs,parent,M,lo,hi,mods,anchor=prepare(n)
        f,v,ix,contain,W,phi=setup(n)
        assert fa==f and v==vs
        ntests=60 if n in DEFAULT_MODULI else 40
        for z in range(ntests):
            mask=0
            for k in range(rng.randint(0,min(12,len(vs)))):
                mask |= contain[rng.randrange(len(vs))]
            profile=np.array([(mask>>i)&1 for i in range(len(vs))],np.int64)
            F=np.asarray(M@profile,dtype=np.int64)
            assert tuple(map(int,F))==spec(mask,fa,vs,ix,W),(n,z,'transform')
            result=graph(tuple(map(int,F)),fa,vs,ix)[2]
            assert bool(inspect(F,lo,hi,mods,anchor))==bool(result),(n,z,'graph')
            checks+=1
        print('crosschecked',n,ntests,'upsets',flush=True)
    print('TOTAL',checks,'crosschecked monotone profiles',flush=True)

if __name__=='__main__':run()
