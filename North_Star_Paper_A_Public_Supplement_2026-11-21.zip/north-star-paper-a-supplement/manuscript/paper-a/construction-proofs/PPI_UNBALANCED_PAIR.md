# A 113-prime pair using two-prime partial upper interpolation

**PPI-UP1.** Two subgroup unions in the cyclic group specified below have identical autocorrelation at every labeled shift and different translation orbits. Its distinct odd primes comprise 48 fixed primes, 46 damping primes and 19 spectator primes. The dyadic exponent is 3475.

## Fixed blocks

Use the hidden group of order $5^2 11^2 13\cdot17$ and the 16 signed coatom fibers in the [certificate](../../../experiments/ppi_unbalanced_pair.py). Hidden shell indices are mixed-radix indices with the exponent at 5 changing fastest. The verifier computes their masses as products of Euler totients and checks that every one-step increase from a listed shell stays in its fiber. On quotient axis $i$ of modulus $p_i^{a_i}$, coatom $i$ uses order $p_i^{a_i-1}$ and full order on all others. It has the sign in the input on its hidden upset and vanishes elsewhere. The support is order-convex, with constant sign on comparable support points.

The full-to-previous shell mass ratio is $\rho_i=p_i-1$ at $a_i=1$ and $p_i$ at $a_i=2$. Each hidden fiber has mass $2400 b_i\rho_i$, with $b_i$ in FIBERS. At trivial hidden frequency and quotient conductors of order one or $p_i$, factor out the nonzero product of full-shell character sums. The remaining value is $2400(\sum s_i b_i-\sum_{i\in T}s_i b_i p_i)$, where $s_i$ is the sign of arm $i$. The root and all listed masks are zeros. The incidence minor is 193. As in [PPI-PU1](PPI_PARTIAL_UPPER_PAIR.md), products of the factors $1-p_i1_{\{x_i\bmod p_i=0\}}$ give an upper witness $u$ using those masks. The coefficient sum on masks containing $i$ is $-1/p_i$, and the constant cancels the total coefficient sum. Hence $u$ equals the support indicator on the upper closure and annihilates the discrepancy. All $2^{16}$ reduced order values are checked and $\|u\|_\infty<602953959432$.

Retain the 14-prime lower donor of PPI-WF1. Apply the [modular anchor construction](PPI_MODULAR_PAIR.md) to the two individual denominators with upper multiplier $249391\cdot2^{32}$ and lower offsets $(304,328,170,462)$. The checker verifies the congruences, the rational and dyadic denominator bounds, and Pocklington certificates for the eight large helper primes. The other fixed axes are the three pairs below.

## Nonzero-mean partial blocks

**PPI-UP2.** For any two distinct odd primes $p<q$, take a local discrepancy $d$ equal to $+1$ at order $p$, $-1$ at order $q$, and zero elsewhere. Its total is $p-q$. At characters nontrivial on both axes each singleton has character sum $-1$, so the product packet $T=(1-p1_{\{x_p=0\}})(1-q1_{\{x_q=0\}})$ annihilates $d$. Write $P_B$ for its support indicator, $Z=(p-1)(q-1)$, and $v=-\alpha T$ for a positive dyadic $\alpha$.

Given an upper witness $u$ on a block with discrepancy $e_A$ and support indicator $P_A$, set $C=P_B-v$ on all nonzero orders of $B$, and $C(0)=0$. Then
\[
 u'=u\otimes C+P_A\otimes v
\]
annihilates $e_A\otimes d$ by the annihilating factor in each summand. On the product upper closure $u=P_A$, so $u'=P_AP_B$. At any point with $P_A=1$ it equals $P_B$ on nonzero orders of $B$ and $-\alpha Z$ at zero. With $P_A=0$ only the first summand contributes. Thus
\[
 \|u'\|_\infty\le\max\{1,\alpha Z,\|u\|_\infty\max_{x\ne0}|P_B(x)-v(x)|\}.
\]
This only increases the dyadic part of the clearing denominator. Apply the formula to $(776561,776563)$, $(881,883)$ and $(29,31)$ in order. The scales in apply_partial_blocks round down on grids with 64, 44 and 34 fractional bits. The successive norm bounds are below 776562, 882 and 31.

## Interpolation with the nonzero-mean blocks

Write $A'$ for the original upper donor times all three pairs, and use their sum of local ranks as $r_{A'}$. The original rank counts full quotient coordinates plus $1-D_A+U_A$, with $D_A,U_A$ the lower and upper closure indicators. Each pair counts active axes. On support the rank is $16+3=19$. The product discrepancy of $A'$ has zero total because its original upper factor does. Its individual partial factors have nonzero total.

Use the rational base and moving interpolation of [PPI-PU1](PPI_PARTIAL_UPPER_PAIR.md) and [the mixed-slot construction](PPI_MIXED_SLOTS_PAIR.md). For a product of local targets $Y_i$, subtracting $\prod_i(Y_i-a_i)$ from $\prod_i Y_i$ gives an annihilator whenever the approximants $a_i$ annihilate their own blocks. The error is precisely the subtracted product. Exactness on either forced closure follows when one local error vanishes there. On stationary $A'$ use $u',1,u'$ for $D,U,P$ respectively. When $A'$ moves, use $19u'$ for $r_{A'}D_{A'}$ and $r_{A'}P_{A'}$. These are exact on its upper closure since $D=P$ there and the rank is 19 on support.

For the single moving product $r_{A'}U$ group $A'$ with the upper modular helper $M_u$. Their joint target factor is $r_{A'}U_{A'}U_{M_u}$, and its approximant is $r_{A'}\otimes1$. This annihilates the joint discrepancy because the modular helper has zero total. It is exact on their upper closure. The first lower donor gives exactness on the lower closure as before. The joint error has magnitude at most the rank bound $m_{A'}$ for $A'$. The stationary first lower has error at most $1+L$, the lower modular helper at most $1/2$, and the $t$ damping factors contribute $2^{-t}$. This term therefore fits the moving-product envelope $m_{A'}(1+U)(1+L)2^{-t-1}$, where $U,L$ denote the individual witness bounds. All other moving products use the earlier rules. Each additive rank term alone is annihilated by an independent balanced block. These facts justify the unchanged rational error inequality in verify_templates.

For the dyadic anchor, start with the paired upper dyadic witness on the original upper block and its modular helper. Multiply it by the three partial-pair support indicators. This is still an annihilator and equals the product support on the combined upper closure. Its norm and dyadic precision are bounded by those of the paired witness. Use this enlarged upper block, the paired lower block, and ordinary centered damping factors in the earlier $2F(D)-F(P)$ dyadic anchor. Its norm satisfies the original anchor bound, and the three additional precision bits allowed by the checker are conservative. The rational and dyadic profiles have the same forced values, so the PPI-WF1 final dyadic blend applies. Comparable equal-rank orders preserve the original quotient reduction states, closure indicators, pair activations, and all other donor inputs. Hence they preserve both profiles and the blend.

## Spectator and the actual sets

Use the [PPI-WD1 order-ideal decoder](PPI_WEIGHTED_DIGIT_PAIR.md) with the following tags. For clarity its parameters are given here.

| Role | Primes and order exponents |
| --- | --- |
| Raw | $3^2,7^2,23^2,37^2,41^2,71$ |
| Guards | $19,43,47,83,109,113$ |
| Fine | $149,197,337,379,433,449,487$ |

Let $K$ be their product with the displayed exponents. Let $B$ be the part of the product of all tag predecessors supported on raw primes. The spectator $S$ has order $KB2^{3475}$. The raw prime factors in $B$ are counted once among the 19 distinct tags. Take the first 23 admissible two-prime damping pairs excluding all tags and fixed axes. The fixed rank bound is 46 and the total rank bound is $R=92$. In the tag quotient the top ordinary degree is 24. Ordinary slots have degree 21 and lack a guard. Fine slots contain every guard and have remaining weighted degree 12 with raw weight one and fine weight three. Their ordinary degree is at most 18. The background fills all strict lower tags as in PPI-WD1. The parameters select the 408 heaviest ordinary slots and split after slot 190. The second list begins at group 95, with minimum depth three. The step is rounded on the $E/2^{204}$ grid and the intercept is the verified midpoint, with free window of two fifths of a step on either side. These rules fix $c,\delta$.

The minimum fine unit is $M=2^{15}$. Use the first 3368 of 3766 fine slots ordered by odd weight, with a unit prefix of 35. The checker tests the weighted tail inequality exactly, together with both endpoints at each of the 93 levels, the free-error envelope including the blend, and the denominator grid. The ordinary base depth is 106 and the fine exponent surcharge at most 15. At each free order the paired greedy and parity rules therefore encode normalized mass $Kw/2$ exactly. The slot heights at successive levels are nested for every choice of digits.

Give both sets this decoded section on each free order of the odd fixed-and-damping group $H$. Give both all of $S$ on the strict lower closure and the empty section on the strict upper closure. On signed support give them opposite full and empty sections, the first full at positive sign. Order convexity and sign consistency give the forced comparisons. The level nesting and equal-rank property give the free comparisons. Thus both are divisor ideals and are subgroup unions. Their distinct even section-size profiles on $H$ cannot be translates, since twice a translating element would be a period and therefore the element itself would be a period. Finally $f-g=e$ throughout each spectator fiber and the fiber sum of $f+g$ is $|S|w$. The sets are even, so at every labeled shift $(z,y)$ the autocorrelation difference is $((f-g)*(f+g))(z,y)=|S|(e*w)(z)=0$.

Run **python3 experiments/ppi_unbalanced_pair.py** with assertions enabled. The damping digest is 8658148e14ac7b5243ba9f33210f5e4eb78ef1c186792f0f9bc7facf9b4fdde6. The at-most-100 goal and independent referee review remain open.

## A threshold alternative for later damping estimates

**PPI-UP3.** Let $t\ge1$ independent damping blocks each have a mean-zero discrepancy, and let $X_i$ be any local zero-one function. For $1\le j\le t$, the product discrepancy annihilates
\[
 \prod_{i=1}^t X_i -
 \frac{(-1)^{t-j}}{\binom{t-1}{j-1}}\,
 1_{\{\sum_i X_i\ge j\}}.
\]
Indeed, in the multilinear expansion on the Boolean cube, the coefficient on the full product in the threshold indicator is $\sum_{k=j}^t(-1)^{t-k}\binom tk=(-1)^{t-j}\binom{t-1}{j-1}$ by Pascal's identity. Subtraction therefore leaves only monomials missing a block. Each is killed by the discrepancy of its missing block. The residual sup norm is bounded by the reciprocal binomial coefficient. If the $X_i$ are all lower closure indicators, or all upper closure indicators, this residual changes value at most once along any order chain. For support indicators the count can increase or decrease. Using this formula to reduce template ranks would require a new moving-rank estimate and denominator check. The 113-prime certificate uses the previously proved midpoint damping formula throughout.
