# A Level 1 pair on 142 distinct odd primes

**PPI-PU1.** There are two distinct subgroup unions in the same cyclic group with identical autocorrelation at every labeled shift and different translation orbits. The group below has 142 distinct odd prime factors and dyadic exponent 3295. The construction uses 49 fixed odd primes, 66 more for damping, and 27 for the spectator. The at-most-100 objective remains open.

## An upper witness with two quadratic primary coordinates

Take the six hidden primes from PPI-WF1 and the 13 entries of FIBERS in the [certificate](../../../experiments/ppi_partial_upper_pair.py). Each entry gives a signed prime $s_i p_i$, a positive multiplier $b_i$, a primary exponent $a_i$, and a hidden shell bitset. The exponents at 31 and 37 are two. All other exponents are one. At coatom $i$ the order on coordinate $i$ is exactly $p_i^{a_i-1}$ and every other primary coordinate has full order. Give this coatom discrepancy $s_i$ over the listed hidden upset. It vanishes elsewhere. Distinct coatoms are incomparable and each fiber is an upset, so the support is order-convex with constant sign on comparable support orders.

Let $\rho_i$ be the ratio of the full-order shell mass to the previous shell mass. It equals $p_i-1$ for $a_i=1$ and $p_i$ for $a_i=2$. Each hidden upset has mass $8832 b_i\rho_i$. To compute the transform at trivial hidden frequency and quotient characters of conductors one or $p_i$, factor out the product of the full-order shell character sums. These sums are nonzero. Replacing the full shell in coordinate $i$ by the previous shell gives ratio $1/\rho_i$ at the trivial character. At conductor $p_i$ the previous shell is in the character kernel and the average on the full shell is $-1/(p_i-1)$. Thus the ratio changes by the factor $1-p_i$. The remaining transform equals
\[
8832\left(\sum_i s_i b_i-\sum_{i\in T}s_i b_i p_i\right)
\]
for conductor mask $T$. Both sums vanish for every listed mask, and the first vanishes at the root.

Use the zero-mean packet factors $1-p_i1_{\{x_i\bmod p_i=0\}}$ on these primary coordinates. They see only the reduction to $C_{p_i}$. Each factor equals one at full order and $1-p_i$ on the previous shell. As in PPI-WF1, the coefficients solve $\sum_{T\ni i}\alpha_T=-1/p_i$ with constant coefficient $-\sum_T\alpha_T$. The 12-row minor is 113 and the checker verifies the remaining equation. The witness $u$ equals one on support and zero on the rest of the upper closure. Indeed, increasing the hidden order at the same coatom stays in the upset, and every strictly higher quotient order has full order on all 13 coordinates. The clearing denominator is $d_u=113\prod_i p_i$. Exact evaluation at all $2^{13}$ reduction masks gives $\|u\|_\infty<428778222$.

Keep the 14-prime first lower donor of PPI-WF1. Use the four-prime modular anchor rules of that proof with the new upper denominator, upper multiplier $73572\cdot2^{67}$ and lower offsets $(78,1340,64,1354)$. The verifier checks both denominators, all congruences, distinctness, and primality by Pocklington. These 41 fixed primes supply the original upper/lower dyadic anchors. [Modular anchor proof](PPI_MODULAR_PAIR.md) · [Lower witness and section construction](PPI_WEIGHTED_FIBER_PAIR.md)

## Partial upper interpolation

**PPI-PU2.** Let $e_A$ be an odd-block discrepancy with support indicator $P_A$, and let $u$ annihilate it by convolution and equal $P_A$ on its upper closure. Take a disjoint prime quadruple $a<b<c<d$ with $a+d=b+c$. On block $B$ give the first and last singleton prime orders positive sign, and the other two negative sign. This discrepancy has total zero and vanishes in Fourier space on the fully nontrivial conductor. The latter follows because each singleton shell has character sum $-1$ there.

Write $T(x)=\prod_{p\in B}(1-p1_{\{x_p=0\}})$, $Z=\prod_{p\in B}(p-1)$, and take a positive dyadic $\alpha$. Then $v=-\alpha T$ annihilates the discrepancy. With $P_B$ the singleton indicator, set $C=P_B-v$ on the upper closure of $B$ (all nonzero orders), and set $C(0)=0$. On $A\times B$ use
\[
u'=u\otimes C+P_A\otimes v.
\]
Each summand has an annihilating factor. On the product upper closure $u=P_A$ and $C+v=P_B$, proving exact upper interpolation. Its global norm satisfies
\[
\|u'\|_\infty\le\max\{1,\ \alpha Z,\ \|u\|_\infty\max_{x\ne0}|P_B(x)-v(x)|\}.
\]
To see this, when $P_A=0$ only the first term survives. When $P_A=1$, also $u=1$, and the result is $P_B$ at nonzero orders of $B$ and $-\alpha Z$ at its origin. At singleton $p$ the packet $v$ has value $\alpha Z/(p-1)$. At larger orders its magnitude drops by another predecessor factor. This permits a small error on the upper closure even when the value at the origin is large.

Apply this rule first to $(43781,43783,43787,43789)$ and then to $(457,461,463,467)$. The script chooses $\alpha$ by downward dyadic rounding and checks all 15 nonzero orders at each step. The first step uses 86 fractional bits and gives norm below 43784. The second uses 60 bits and gives norm below **475**. The construction introduces no odd denominator in addition to that of $u$.

## From witnesses to section densities

Group the original upper block and the two new singleton blocks into one block $A'$. Its local rank is the sum of their three ranks. Use the number of full-order primary coordinates plus $1-D_A+U_A$ in the original upper block, where $D_A,U_A$ indicate its lower and upper closures. Use activity counts in the two new blocks. Equal ranks on comparable orders preserve every constituent quotient activity and closure bit, hence all inputs to the two partial witnesses. This includes the comparison from order 1 to order $p$ on a squared primary coordinate, where reduction modulo $p$ is unchanged. On the support of $A'$ the rank is $13+1+1=15$.

Use the base and moving products of PPI-WF1, with the new $u'$ as the upper witness on $A'$. In the stationary case the three upper approximants for $D,U,P$ are $u',1,u'$. When $A'$ is the moving block they are $15u',r_{A'},15u'$. On its upper closure one has $D_{A'}=P_{A'}$, and the rank is 15 on support, so these are the required moving values. The middle approximant $r_{A'}$ annihilates the product discrepancy because it is a sum of three single-block functions and the other blocks have zero total. Its error for $r_{A'}U_{A'}$ has magnitude at most the maximum rank of $A'$. The other two moving errors are bounded by that maximum times $1+\|u'\|_\infty$. They therefore satisfy the earlier moving-product bound. The first lower block supplies exactness on the lower closure, with the same lower approximants as before.

Take the first 33 two-prime damping blocks in the PPI-WF1 scan excluding all fixed and spectator axes. Write $H$ for the resulting odd group and $e$ for the product discrepancy. The fixed rank is 45 and the total rank bound is $R=111$. Use the PPI-WF1 rational profile $w_r$, which annihilates $e$, equals $2-P$ on the lower closure and $P$ on the upper closure. In its error estimate use $t=33$, the new upper norm and the original lower norm. For the dyadic anchor $w_0$ use the paired anchors on the original 41 fixed primes, and independent ordinary midpoint factors on the two new blocks as well as the damping blocks. This anchor has the same forced values and annihilation. Its old norm bound still applies and its dyadic precision costs two additional bits. The rational profile pays at most $86+60$ additional bits, with its old odd clearing factor. Thus the proof of the final dyadic blend applies with the exponents in partial_bounds. In the normalized units below, $Kw$ is dyadic and the free error about $c-\delta r$ is less than $3\delta/8$. The checker verifies the error including the final blend, not just the rational profile.

## The two sets

Use the PPI-WF1 spectator rules on these three ordered tag lists.

| Tag list | Primes |
| --- | --- |
| $G$ | 13, 19, 29, 73, 83, 89, 97, 103, 127 |
| $J$ | 167, 179, 257, 389 |
| $F$ | 509, 677, 929, 1103, 1217, 1553, 2657, 3329, 3797, 4409, 4673, 7829, 9257, 9629 |

Here $K$ is the product of all 27 tags, and $B$ the product of the odd parts of predecessors on $J\cup F$. Its prime factors belong to $G$. The cyclic spectator $S$ has order $KB2^{3295}$. Ordinary tags omit three primes including a member of $J$. Fine tags contain $J$, seven members of $F$ and none of $G$. Use the strict background rule of PPI-WF1 with ordinary size 24. It covers every strict divisor, while the two slot types are incomparable. The fine rule uses the subgroup of order $B/\operatorname{oddpart}(V)$ in the kernel over the zero $G$ coordinates, precisely as in that proof.

Order and normalize the 650 heaviest of the 1154 ordinary slots by the same extreme-pair and prefix-mean rule, splitting the list after slot 252. Set the step on the $E/2^{69}$ grid and use the midpoint intercept in verify_templates with margin $3/8$ of a step. This specifies $c,\delta$ exactly. At level $l=111-r$ use ordinary depth 192 and $A=3272$ fine bits of mass unit $M=2^{26}$. The late ordinary groups start at group 126, hence their virtual heights are used at depth at least 15. The verifier checks they fit even when doubled. Fine capacity is $3432\ge3272+111$ and the largest additional height exponent is 23. The decoder checks both endpoints at all 112 levels. The PPI-WF1 greedy induction covers the interval between them, and the verified grid bound gives exact fine decoding of every actual $Kw/2$. Thus a free order receives a section of density $w/2$. All choices at one level contain every choice at the preceding level. Comparable equal-rank orders give identical sections.

On free orders give both sets the decoded section. On the strict lower closure give both the full spectator, on the strict upper closure give both the empty spectator, and on signed support give opposite full and empty sections with the first set full at positive sign. Order-convexity, compatible signs and the nesting just proved make both sets divisor ideals, hence subgroup unions. Their even section-size profiles on odd $H$ differ on support and cannot be translates. Indeed a translation between two even profiles by $a$ makes $2a$ a period and therefore $a$ a period. The two even indicators $f,g$ differ by $e$ independently of the spectator input, and their sum over each spectator fiber is $|S|w$. For every labeled shift $(z,y)$ the autocorrelation difference equals $((f-g)*(f+g))(z,y)=|S|(e*w)(z)=0$.

Run **python3 experiments/ppi_partial_upper_pair.py** with assertions enabled. The expected damping digest is 23e5252c352377b5fc2c291df5f491d1f66fc88f7e4316dbb10b66822fee5f28. This is a symbolic all-shifts proof with exact arithmetic checks. Separate referee review remains pending.
