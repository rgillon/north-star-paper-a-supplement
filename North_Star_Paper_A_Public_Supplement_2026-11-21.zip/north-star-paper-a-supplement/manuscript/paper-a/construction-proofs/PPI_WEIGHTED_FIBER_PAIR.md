# A Level 1 pair on 169 distinct odd primes

**PPI-WF1.** The following finite rules specify two distinct unions of subgroups of one cyclic group. Their autocorrelations agree at every labeled shift and they lie in different translation orbits. The four fixed blocks use 48 odd primes, the 48 damping blocks use 96, and the spectator uses 25. The dyadic factor has order $2^{3264}$. The 100-prime problem remains open.

## Weighted upper fibers

Use the lists HIDDEN, FIBERS, MASKS and LOWER in the [certificate](../../../experiments/ppi_weighted_fibers.py). A FIBERS triple specifies a signed quotient prime $s_i p_i$, a positive integer $b_i$, and a hidden order bitset. Bit $j$ selects the order given by the set bits of $j$ in HIDDEN. The discrepancy is $s_i$ over this fiber at the quotient coatom missing $p_i$, and zero elsewhere. Each fiber is an upset of mass $6192 b_i(p_i-1)$, checked by summing its hidden shell weights. The support is order-convex, with constant sign on comparable support orders.

At a character trivial on the hidden group, let $T$ be its nontrivial quotient coordinates. The active-shell character sum at coordinate $j$ is $p_j-1$ for a trivial component and $-1$ otherwise. Factoring out the nonzero product of these sums from the discrepancy transform leaves
\[
6192\left(\sum_i s_i b_i-\sum_{i\in T}s_i b_i p_i\right).
\]
The first sum is zero. Each of the 19 listed masks also has zero weighted signed prime sum. Thus the constant and the corresponding quotient packets annihilate the discrepancy. Those packets have no Fourier support at nontrivial hidden characters.

For mask $T$ use the product of $1-p_i1_{\{x_i=0\}}$ over $i\in T$. It is 1 at full quotient order. At coatom $i$ it is $1-p_i$ if $i\in T$, and 1 otherwise. Solve $\sum_{T\ni i}\alpha_T=-1/p_i$ and give the constant coefficient $-\sum_T\alpha_T$. The first 19 incidence rows have minor $-298$, and the checker tests all 20 equations. The resulting upper witness equals one on the support and zero on the rest of its upper closure, where the quotient has full order. Its denominator divides $d_u=298\prod_i p_i$.

The lower discrepancy has the 14 signed singleton shells in LOWER. Their signed predecessor sum is zero. Each listed conductor has zero signed prime sum and hence zero transform. Its normalized packet uses factors equal to 1 at zero and $-1/(p_i-1)$ elsewhere. The incidence equations are $\sum_{T\ni i}\beta_T=(1-p_i)/p_i$. With constant $-\sum_T\beta_T$ the lower witness vanishes at the origin and equals one on every singleton. Take $d_l$ to be the lcm of the constant denominator and all $\operatorname{den}(\beta_T)\prod_{i\in T}(p_i-1)$.

The verifier evaluates each entire order table. At one axis, entries $a,b$ indexed by absence and presence of the conductor bit become $a+b,a+(1-p)b$ for the upper witness, or $a+b,a-b/(p-1)$ for the lower one. Successive applications are tensor evaluation of the packet expansion. After scaling, all operations are integral. The $2^{20}$ upper and $2^{14}$ lower orders give sup norms $U<1746300$ and $L<2.447$.

## Annihilation and precision

Use the helpers and paired dyadic anchors from the [modular construction](PPI_MODULAR_PAIR.md). In its upper formula take multiplier 72856 times $d_u$ times the primorial through 31. In its lower formula take offsets $64,2358,0,2422$, in order, with the odd part of $d_l$ as modulus. The first and second pairs of offsets have equal sums. Pocklington certifies all eight primes. For the lower primes the checker includes the certified upper prime and all prime divisors below 1000 of the candidate minus one. It checks the anchor congruences on every required local order.

Use the first 48 disjoint damping blocks of order $p^2q$, $q=p(p-1)+1$, from the verifier scan after excluding the fixed and spectator primes. The two signed shells have orders $p^2,q$, opposite signs and equal masses. Let $H$ be the odd product of all fixed and damping blocks and $e$ their product discrepancy. Write $D,C,P$ for the indicators of its lower closure, upper closure and support. Order-convexity gives $DC=P$. Use the [individual block ranks](PPI_BLOCK_RANK_PAIR.md). The upper donor counts active quotient axes plus $1-D_i+C_i$, the lower donor and both helpers count active axes, and a damping block contributes $1-D_i+C_i$. The sum $r_H$ is weakly increasing and bounded by $R=44+2(48)=140$. Comparable orders at equal rank preserve all the quotient activities, closure indicators and packet inputs used below.

Use the [mixed-slot interpolation](PPI_MIXED_SLOTS_PAIR.md#rational-interpolation-and-boundary-anchor) with these witnesses. Explicitly its rational profile is
\[
 w_r=c+(2-c)F(D)-cF(C)+(c-1)F(P)
 -\delta\sum_j[r_j-G_j(D)-G_j(C)+G_j(P)].
\]
Here $F(X)=X-\prod_i(X_i-a_i)$, and $G_j$ applies this formula to $r_j X$ with the moving approximants in the block-rank proof. The stationary factors include the flat lower-helper approximation to its upper closure. Each surviving expansion term has an annihilating local factor. Exactness on both forced closures follows from the first lower and first upper witnesses. These arguments use their annihilation, boundary values and norms, all established above.

Let $w_0=2F(D)-F(P)$ using the paired dyadic anchors of the same construction. Both profiles annihilate $e$ and give $2-P$ on $D$ and $P$ on $C$. The choices below make $Kc,K\delta$ dyadic, so the odd denominator of $Kw_r$ divides $E=\operatorname{oddpart}(d_ud_l)$. For $\eta=1/(\min q_{\rm lower}-1)$ the mixed-slot product bound for the free-order error relative to $c-\delta r_H$ is
\[
 2^{-48}\left[\frac{2(1+U)+(1+U)(1+L)}4+(1+L)\eta+
 \tfrac32 R\delta(1+U)(1+L)\right].
\]
For $m=16/5$ the checker verifies this expression plus $\delta/(33m)$ is below $\delta/m$. It takes a dyadic $\lambda$ having numerator divisible by $E$, with $(1-\lambda)$ times the anchor difference bound below $\delta/(33m)$. That difference bound applies since $0<c-\delta R\le c<2$, $\delta<1$, and hence $\|w_r\|_\infty<3$. Consequently $w=\lambda w_r+(1-\lambda)w_0$ has $Kw$ dyadic, has the same annihilation and forced values, and differs from $c-\delta r_H$ by less than $5\delta/16$ on free orders.

## The spectator

| Set | Primes |
| --- | --- |
| $G$ | 13, 19, 29, 89, 97, 103, 157 |
| $J$ | 179, 257, 389, 677 |
| $F$ | 929, 1103, 1217, 1553, 3329, 4409, 7829, 9257, 9803, 11393, 11933, 13313, 13457, 14327 |

Set $K=\prod_{p\in G\cup J\cup F}p$ and $B=\prod_{p\in J\cup F}\operatorname{oddpart}(p-1)$. Every prime of $B$ belongs to $G$. The spectator $S$ is cyclic of order $KB2^{3264}$. Its odd component maps onto $C_K$ by reduction with kernel of order $B$. A tag is the active set of a projected order. Measure section sizes in units of $B2^{3264}$.

Ordinary slots have 22 active tag coordinates and omit at least one member of $J$. Fine slots contain all $J$, seven members of $F$, and none of $G$. The 970 ordinary and 3432 fine slots form an antichain. Across the two types this follows from the missing member of $J$ and the strict difference in cardinalities.

Fill all tags missing a member of $J$ with fewer than 22 active coordinates. Also fill tags containing $J$ with $G$ inactive and fewer than seven active $F$ coordinates. This background is a downset containing every strict divisor of every slot. Deleting a member of $J$ from a tag of the second kind leaves size below 22. Write $W_X(i)$ for the total shell weight of size $i$ on axes $X$ and $V_J=\prod_{p\in J}(p-1)$. The normalized background mass is
\[
 n=\sum_{i<22}W_{G\cup J\cup F}(i)
 -V_J\sum_{i<18}W_{G\cup F}(i)
 +V_J\sum_{i<7}W_F(i).
\]

On an ordinary slot of shell weight $V$ take the full odd preimage and a dyadic subgroup of relative height $h$, contributing $Vh$. For a fine slot let $M=2^{26}$, the smallest 2-part of a fine weight. The projected $G$ coordinates vanish, so all their lifts lie in the kernel. Use its subgroup of order $B/\operatorname{oddpart}(V)$ and the dyadic subgroup of relative height $hM/2^{v_2(V)}$. The normalized contribution is $Mh$. This works even though $B$ shares primes with $K$. All affected primary coordinates project to zero in every fine slot. Divisors projecting to the same tag preserve the subgroup restrictions, and divisors projecting to strict subtags are in the full background. The additional height exponent is at most 31.

## Rank templates and decoding

Keep the 700 heaviest ordinary slots and take $H_0$ to be the verifier's power of two at most half the 320th weight. Normalize each $V$ to its unique $v=2^{-s_V}V$ in $(H_0/2,H_0]$, allowing signed $s_V$. Within each of positions 1 through 320 and 321 through 700 separately, sort by $v$, pair the extremes and sort the pairs by sum. Order each list by choosing the smallest remaining sum when its prefix is above its own mean per pair, or the largest remaining sum otherwise. Concatenate the lists. Stable ties inherit the lexicographic index order of the omitted triples on $G,J,F$. Take the step $s$ to be twice the first list's mean pair sum rounded to the nearest multiple of $E/2^{117}$ as in the code, and put $\delta=2s/K$.

At level $l=R-r_H$, groups before $l$ are frozen at doubled base height. Use groups $l+j$, $0\le j\le193$, at base heights divided by $2^j$, each optionally doubled. Later groups are empty. The second list begins at group 160, indexed from zero, so its minimum used depth is 20. The checked inequality $2H_0\le V_{700}2^{20}$ ensures even its doubled heights fit. At fine positions $l+j$, $1\le j\le A=3233$, use nominal height $2^{-j}$ optionally doubled. Earlier positions are frozen at one and later ones are empty. Fine positions start at one and follow lexicographic order. There are enough since $A+R\le3432$. Each possible level contains every choice of the preceding level, slot by slot.

Let $b_l$ be the baseline of both slot families at level $l$, excluding $n$. For an explicit intercept $b$, intersect over all $l$ the intervals with lower endpoint $b_l+M/2^A-ls+5s/16$ and upper endpoint $b_l+M/2^A-ls+v_{l,1}+v_{l,2}+H_0-5s/16$, where $v_{l,1},v_{l,2}$ are the current group's base weights. The term $M/2^A$ cancels the last fine bit in $b_l$, so the midpoint $b$ can be computed before $A$. Put $c=2(n+b+Rs)/K$. For all 141 levels the checker verifies that subtracting $n+b_l$ from either endpoint $n+b+ls\pm5s/16$ leaves a residual between zero and $v_{l,1}+v_{l,2}+H_0$. The interpolation bound places every actual $Kw/2$ between those endpoints.

Greedily take each ordinary increment that fits. After group zero the remainder is at most $H_0$, whether some increment was skipped or both were taken. Entering group $j\ge1$ it is at most $2H_0/2^j$. Each increment is at most $H_0/2^j$ and their sum exceeds $H_0/2^j$. Thus the new remainder is at most $H_0/2^j$. After group 193 it is at most $M/2$. It is a multiple of $M/2^A$ by the dyadic denominator bound in verify_templates. In detail, the rational profile costs at most 48 plus the coefficient, donor and flat-helper exponents in that bound. The paired anchor costs at most $48+887+1893$, and the final blend adds its precision. The verifier also bounds ordinary digit precision by the bit length of $K$ plus the depth, allows for division by $2M$, and checks the endpoints exactly. The fine binary digits therefore encode the remainder. Every free section has density $w/2$.

## Subgroup unions and all labeled shifts

Use the decoded section in both sets at each free $H$-order. On $D\setminus P$ take the full spectator in both, on $C\setminus P$ the empty section in both, and on $P$ take opposite full and empty sections, the first set full where $e=1$. Signs and order-convexity give containment across forced comparisons. For comparable free orders, raising the rank decreases the template level, and equal ranks preserve the profile and the decoded section. Both sets are therefore divisor ideals of element orders and hence subgroup unions.

Their section sizes differ on the support. If the sets were translates, their even section-size profiles on odd $H$ would be translates by some $a$. Evenness would make $2a$ a period of the first profile. Then $a$ is also a period, contradicting the distinct profiles. Finally the two even indicators $f,g$ satisfy $f-g=e$ independently of the spectator input, and the sum of $f+g$ over the fiber at $x$ is $|S|w(x)$. At every labeled shift $(z,y)$ their autocorrelation difference is $((f-g)*(f+g))(z,y)=|S|(e*w)(z)=0$.

Run **python3 experiments/ppi_weighted_fibers.py** with assertions enabled. Python 3.12.14 and SymPy 1.14.0 reproduced the stated parameters and damping digest 02bb66b1e6f82da94c3c58afe2980516665afc8b6f4cbc87334a7cf4ae1652b1. A second replay from an export of the tracked experiment sources, outside the Git checkout, returned the same parameters and digest. Independent referee review remains pending.

## Limit of this error estimate

**PPI-WF2.** Keeping these fixed blocks, ranks, two-prime damping factors, and the displayed uniform error envelope rules out reaching 100 by spectator changes alone, even if the permitted free error is relaxed to one full rank step. Indeed, even zero spectator cost permits at most 26 damping blocks. Write $B_0=(1+U)(3+L)/4$, using the exact sup norms computed by the verifier. The envelope includes at least $B_0/2^t$. The required range $0<c-R\delta\le c<2$ implies $\delta<2/R$ with $R=44+2t$. For every integer $0\le t\le26$ the exact check gives $B_0R>2^{t+1}$. Hence this envelope already exceeds $\delta$ before its moving and blending terms are counted. This obstruction applies to the specified estimate. The actual interpolation errors can be smaller and a different donor or different bound is outside its scope.
