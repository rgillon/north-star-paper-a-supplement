# A 16,527-odd-prime Level 1 pair

This construction uses 79 fixed donor primes, 640 spectator primes, 15,808 damping primes, and one dyadic axis. It gives two distinct, nontranslated subgroup unions with equal autocorrelation at every labeled shift. The target of at most 100 odd primes remains open.

## Fixed data and ambient group

The four fixed blocks and their signed functions are given by experiments/ppi_reallocated_donors.py and its imported lower lists. The upper blocks have respectively 4+18 and 5+22 axes. The verifier checks the original coatom construction with new hidden primes, upsets, scales and conductors, by the [upper donor argument](PPI_REDUCED_UPPER_DONOR.md). It checks the two [lower donors](PPI_REDUCED_LOWER_DONORS.md) on 13 and 17 axes. On each block the discrepancy e is signed zero-one with sum zero, the intersection of its lower and upper support closures is its support, and comparable support points have equal sign. Each individual upper (lower) interpolant annihilates its discrepancy by convolution and equals the support indicator on the upper (lower) closure. The two combined upper donors have an integer interpolant u, and the paired lower donors have an interpolant l with denominator dividing 2^25. For the upper combination use k times the first interpolant times the second support plus (1−k) times the first support times the second interpolant, with k the centered CRT representative in the verifier. The lower combination uses the nonnegative representative. The individual denominators and norm envelopes in the script come from exact incidence elimination and the sum of packet sup norms. All axes used below are distinct except for the explicit prime-square exponents.

Take h=160, m=2^18. In increasing first-prime order take the first 2h pairs p<q of primes summing to m+2 and avoiding the fixed axes. Group consecutive pairs in quartets. Their product order is K. In each quartet the two singleton shells of either pair have total mass m. Taking one such two-shell union per quartet yields 2^h disjoint antichain collections each of mass M=m^h; strict divisors of collection orders together have mass n=(1+2m)^h−(2m)^h. The spectator group S is cyclic of order K times 2^a with a=18529.

For t=7904 damping blocks scan primes p upward from 2^21, accepting (p,q) when q=p(p−1)+1 is prime and both axes are unused. The block order is p²q, and e is positive on order p² and negative on order q. Each shell has mass p(p−1), and the two are incomparable. Write H for the product of fixed and damping blocks, and e for the product discrepancy. On each block let D,U,P denote the indicators of the lower closure, upper closure and support respectively. On products these are the corresponding products, with DU=P. Let I=1−D−U+P. Rank r is the sum of indicators of individual prime-power thresholds, counting both p and p² separately. Rank increases strictly along strict order comparisons and is at most R=79+3t.

## Annihilating interpolation

The following is the product interpolation of PPI-CE1, with the local order chains and parameter checks changed. For X=D,U,P use the combined upper and lower blocks A,B. On A use approximants u,1,u respectively, and on B use 1,l,l respectively. On every damping block use 1/2. Write F(X)=X minus the product over blocks of the local differences between X and its approximant. In its expansion each surviving product contains an annihilating factor, so e*F(X)=0. On global U the upper-block difference is zero, and on global D the lower-block difference is zero. The other t differences have magnitude 1/2.

For each rank threshold indicator b define F_b(X) by subtracting from bX the product of b and all local differences, now treating the four fixed blocks separately. Select the first upper and first lower donor outside the block containing b, in the displayed certificate order. On these selected blocks use the individual approximants according to the same rule. Center damping blocks by 1/2 except any containing b. Use zero approximants elsewhere. Each surviving expansion term again has an annihilator outside the moving block, so its convolution with e vanishes. The correction is exact on D and U; at least t−1 damping differences are centered. Also e*b=0 since at least one other block has zero total.

Use the verifier's exact grid constants c and delta. Explicitly g=6827, c is (2n+M)/K rounded upward to a multiple of 2^(−g), and delta=E/2^7718, with E the odd part of the product of the four certified individual denominators. Set

    w = c + (2−c)F(D) − cF(U) + (c−1)F(P)
          − delta sum_b [b − F_b(D) − F_b(U) + F_b(P)].

This has e*w=0. Replacing each F by its uncorrected target gives 2D−P+cI−delta rI. Equality with that target holds on D and U. Everywhere the absolute error is at most

    2^(−t) [4(1+upper_bound)(1+lower_bound)
              +6 R delta (1+individual_upper_max)(1+individual_lower_max)].

Indeed 0<c<2, the absolute base coefficients total at most four, and the three moving corrections each lose at most one centered factor. The verifier checks this bound is strictly below delta/3. On I it checks both extreme ranks with this error against the open interval (2n/K,2(n+M)/K). Strict decrease along comparable distinct free orders survives since their target gap is at least delta.

## Exact binary sections and the labeled identity

The distinct values of v=(Kw/2−n)/M on I lie strictly between zero and one. Their denominators divide 2^a. To see this, the base part of w has dyadic exponent at most g+t+25. In the moving part E clears all odd denominators, and the remaining exponent is at most s+t plus the maximum upper and maximum lower individual dyadic exponents combined, where s=7718. Scaling to v adds 18h+1 places. These bounds give the verifier's a. The 79 fixed axes have at most 2^79 patterns. Each damping block has six order types (three p-exponents and two q-exponents). Permutations of whole damping blocks preserve the formula, including the sum over moving indicators: local D,U,P, rank thresholds and donor selections depend only on the block type and its role. Thus there are at most 2^79 binom(t+5,5) distinct free values. The verifier checks this times a is at most 2^h.

Sort the distinct v increasingly, preceded by zero. For each nonzero digit 2^(−j) in each successive difference, assign the next unused spectator collection in binary lexicographic order (within a quartet use the earlier prime pair first). For a given v include the full dyadic fiber on the strict lower background and the subgroup of size 2^(a−j) above every collection assigned up to that v. All other fibers are empty. These nested sections are divisor ideals by incomparability and the full lower background. Their densities are (n+Mv)/K=w/2.

Define the two sets by sections in S above x in H. On D outside P both are all S, on U outside P both are empty, and on I both are the common section just assigned. On e=+1 use all S for the first and empty for the second, reversing at e=−1. They are downsets in element order, hence subgroup unions: comparable support signs agree, free orders are incomparable with support, and the free sections increase downward. The strict lower background in H is a downset and the strict upper region an upset by DU=P and order-convexity of support. Their indicators f,g are even and differ by e(x) throughout each section. The section sum of f+g is |S|w(x). For every (z,y) the difference of labeled autocorrelations therefore equals ((f−g)*(f+g))(z,y)=|S|(e*w)(z)=0. Both signs occur, so the sets differ. Their even section-size profiles on H cannot be translates: a translation by h' would make 2h' a period of the first profile by evenness, hence h' a period since H is odd. The profiles would agree, contradicting the opposite full and empty sections.

## Reproduction and scope

The two standard input verifiers are pinned to commit c8dbda833f437371efc12b9c1205006bef6cebac. Fetch it if needed. From the repository root run with Python 3, SymPy and assertions enabled:

    python3 experiments/ppi_reallocated_donors.py
    python3 experiments/ppi_reallocated_pair.py

The scripts verify the donor equations, prime supply and disjointness, rational bounds, dyadic precision, and spectator capacity. The proof handles all orders and shifts symbolically. The damping list digest is 68efa2092f93ca73ffaba3e188cae4db401a374b388a59fdd1d476c3263c4ea9. This is a same-session proof and reproducible computation. Independent review remains pending.
