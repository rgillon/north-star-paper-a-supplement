# Compressing the second upper donor in PPI-CE1

The second upper donor admits a replacement with 46 quotient primes and the original five hidden primes. Together with the original first upper donor and the two lower donors this gives 112 distinct fixed primes. This is a donor certificate. The spectator, error estimates, rank correction and binary realization for a full instance have not been recomputed.

## Construction and proof

Use the source table in commit c8dbda833f437371efc12b9c1205006bef6cebac. The zero-based indices, in order, and the binary conductor masks are recorded in experiments/ppi_reduced_upper.py. Keep the hidden upset attached to each selected prime. Give the first 23 indices positive sign and the last 23 negative sign. On the quotient coatom missing coordinate i, let the signed discrepancy equal that sign on its hidden upset and zero elsewhere. Distinct coatoms are incomparable and each hidden fiber is an upset, so the signed support has constant sign on comparable pairs and is the intersection of its upper and lower closures.

Each upset has size 12(p_i−1), checked by summing its listed shell sizes. Thus all coatoms contribute equal unsigned mass and the total signed mass vanishes. At trivial hidden frequency the quotient Fourier coefficient is proportional to the signed sum of primes in the conductor: the coatom i term is 12 times its sign times the product of all single-axis top-shell transforms, times (p_i−1) divided by its own top-shell transform. The latter ratio is 1 off the conductor and 1−p_i on it. The signs sum to zero, so every listed zero-sum conductor is a Fourier zero, as is the empty conductor.

Let the matrix have one row per prime and one column per listed conductor, with entries indicating membership. Its minor omitting the last prime has determinant −4346855. The vector of signed primes annihilates every column and is orthogonal to the target vector with entries −1/p_i, since there are equally many signs. Therefore the system with that target is solvable, and the denominator divides the absolute determinant times the product of the primes. For each column use the inverse character packet normalized to one at quotient top order; on coatom i it equals 1−p_i for a column containing i and one otherwise. Weight by the solution, then subtract its coefficient sum as a constant. This function is zero at the top and one on every coatom, hence agrees with the unsigned support on its upper closure. Its convolution with the signed discrepancy vanishes by the Fourier zeros above. The denominator bound is coprime to that of the original first donor. Consequently the two rational upper witnesses combine into an integer witness by the original Bézout construction.

## Limit on compressing this prime pool

For any signed balanced selection from the same 100 quotient primes, at least one conductor used by this interpolation must have unequal counts of positive and negative primes. Otherwise the sign vector itself annihilates every incidence column, but its pairing with the target is nonzero. Indeed multiply the signed reciprocal sum by the product of selected primes and reduce modulo any selected prime. Exactly one nonzero term survives.

In a zero-sum conductor the counts on the two sides have the same parity because every prime is odd. If the larger count is m and the counts differ, the smaller is at most m−2. For m from 3 through 17 inclusive the sum of the m smallest primes in the entire pool exceeds the sum of the m−2 largest by at least 23628 (exact endpoint sums checked by the script); m at most two cannot yield a nonempty unequal relation. Thus m is at least 18. Balanced sign counts in the whole donor force at least 36 quotient primes. With the five hidden primes and the other fixed donors unchanged, the fixed total is at least 19+18+24+5+36=102, even before padding or spectators. This argument applies to the stated quotient pool and quotient-only packet interpolation.

## Reproduction

Fetch the pinned commit if absent, then run from the repository root with assertions enabled:

    git fetch origin c8dbda833f437371efc12b9c1205006bef6cebac
    python3 experiments/ppi_reduced_upper.py

The checker loads the original exact donor verification routine by Git object ID. It checks the new masks, all shell sizes and signs, the minor, the interpolation equations, the denominator gcd and the extremal gap. The search used equal-sum subset matching and rank selection; verification does not depend on repeating the search. Same-session proof and computation; separate review pending.
