# A 133-prime Level 1 pair with odd-weight binary digits

**PPI-WD1.** There are distinct nontranslated subgroup unions with identical labeled autocorrelation at every shift in a cyclic group with 133 distinct odd prime factors and dyadic exponent 3398. Take the 49 fixed primes and odd discrepancy functions of [PPI-PU1](PPI_PARTIAL_UPPER_PAIR.md), the 33 damping pairs selected below, and the 18 spectator tags in the table. The change from 142 primes is entirely in the spectator.

| Tag set | Primes | Exponents in the tag quotient |
| --- | --- | --- |
| Raw $G$ | 13, 19, 29, 73, 83, 89, 97 | two on the first five, one on the last two |
| Guards $J$ | 167, 179, 257, 389, 677 | one |
| Fine $F$ | 929, 1103, 1217, 1553, 2657, 3329 | one |

Let $K$ be this quotient order. Let $B$ be the largest divisor of the product of all 18 tag predecessors supported on $G$. The odd spectator has order $KB$ and projects onto the tag quotient with kernel of order $B$. Measure all section masses in units of $B2^{3398}$. An unrestricted preimage of a tag order of shell weight $V$ therefore contributes $V$. The full normalized mass is $K$. Exclude all tags as well as the fixed primes when scanning for damping pairs by the PPI-PU1 rule. The group $H$ on the fixed and damping coordinates is odd and coprime to the spectator.

## The background and variable slots

Use the sum of tag exponents as ordinary degree. Its maximum is 23. Ordinary slots have degree 20 and are missing at least one guard. Fine slots contain all guards, and their remaining exponents have weighted degree eight, counting $G$ with weight one and $F$ with weight two. These orders are pairwise incomparable. Within each family distinct comparable orders have distinct degrees in its grading. A fine order has ordinary degree at most 13, and it contains a guard missing from each ordinary order.

Fill every tag order missing a guard with degree below 20. With all guards present fill those with remaining weighted degree below eight. This is a downset containing every strict divisor of a slot. The normalized mass $n$ sums the ordinary masses of all orders of degree below 20, subtracts the part with all guards present, and adds the weighted-degree background with all guards present. The rank_masses recurrence in the verifier multiplies the one-coordinate shell-mass polynomials to do these sums exactly.

Use the 486 heaviest of the 555 ordinary slots, with the ordering, normalization and greedy rule of [PPI-WF1](PPI_WEIGHTED_FIBER_PAIR.md). Ties in the initial descending weight sort inherit lexicographic order of deficit triples on the displayed tag order. Split after 234 slots. Write $H_0$ for the power-of-two target, $s$ for the rounded step, and $b$ for the intercept returned by verify_templates. Each group contains two base weights in $(H_0/2,H_0]$. The second list begins at group 117 and is used at depth at least six, so its doubled virtual heights fit by the checked tail inequality. Put $R=111$, $\delta=2s/K$ and $c=2(n+b+Rs)/K$. The step is rounded on the $E/2^{142}$ grid of PPI-PU1.

For a fine slot of weight $V$, take $B_0$ to be the full factor of $B$ supported on its inactive raw primes. Put
\[
 d_V=\gcd(\operatorname{oddpart}(V),B_0),\qquad
 w_V=\operatorname{oddpart}(V)/d_V.
\]
On these inactive coordinates restrict the lift to the subgroup of index $d_V$ in their kernel. Such lifts project to zero. Use the full lifts on every other odd coordinate. With $M=2^{19}$ the smallest 2-part of a fine weight, use dyadic relative height $hM/2^{v_2(V)}$ at nominal height $h$. The contribution is $M w_V h$. Each $w_V$ is odd. Dividing an order without changing its tag preserves these restrictions, and all strict subtag divisors are in the background. The maximum additional dyadic exponent from this scaling is 22.

## Reusing the fine slots at every level

**PPI-WD2.** Consider $A$ positive odd integer weights $w_j$ with $w_j=1$ for $1\le j\le J_0$ and $\sum_{j>J_0}w_j2^{-j}<1/4$. Every multiple $y$ of $2^{-A}$ in $[1/4,3/4]$ is a subset sum of the $w_j2^{-j}$. Starting with $z=2^Ay$, visit $j=A,\ldots,J_0+1$. Select digit $j$ if $z$ is odd, subtract $w_j$ when selected, and divide by two. Each division is exact. The total possible subtracted mass is below $1/4$, so the remaining scaled value at the stopping point is an integer in $[0,2^{J_0})$. Its ordinary binary expansion selects the remaining digits. This proves the claim on the entire grid.

Sort fine slots by $w_V$, breaking ties lexicographically by the exponents on $G,F$. Use the first $A=3265$ of 3607 slots. The first 15 weights are one, and the checker verifies the tail inequality above by an integer sum. Write $T=\sum_{j=1}^A w_j2^{-j}$. At level $l=R-r$, put $\lambda_l=2^{l-R}$. Use the same fine positions at every level, with minimum height $\lambda_l2^{-j}$ and optional doubling. Their minimum total is $M\lambda_l T$. The maximum possible height at one level equals the minimum at the next, slot by slot.

Freeze ordinary groups before $l$ at doubled base heights. Use groups $l+j$ through the fixed last index $R+126$, with base heights divided by $2^j$ and optional doubling. Unused groups are empty. Thus the depth is $126+R-l$ and the ordinary heights are nested between all successive levels. Write $C_l$ for the ordinary minimum including frozen mass. To select the intercept use the midpoint rule in verify_templates with provisional baseline $C_l+5M\lambda_l/4$, relative margin $2s/5$ and upper residual bound given by the current group sum plus $H_0$. For the actual decoding subtract $C_l+M\lambda_l T+M\lambda_l/4$ from the incremental target above the background. The last term reserves mass for fine decoding. The verifier checks at both interval endpoints for all 112 levels that the resulting number belongs to the permitted ordinary range.

Greedily take each ordinary increment that fits. The paired-group induction of PPI-WF1 leaves at most $H_0/2^{126+R-l}\le M\lambda_l/2$. Including the reserve leaves a fine increment in $[M\lambda_l/4,3M\lambda_l/4]$. After dividing by $M\lambda_l$ it is on the $2^{-A}$ grid. In detail, the old bound in verify_templates covers the dyadic precision of $Kw/2$, the final blend, and division by $M$. Ordinary digits have at most the binary length of $K$ plus $126+R$ fractional bits before division by $M$. The checker reserves those bits too. Division by $\lambda_l$ multiplies by an integer, and the scaled fine baseline $T$ already lies on this grid. PPI-WD2 therefore decodes every possible free-order target, including the interior of every checked interval. The lowest fine height uses at most $A+R+22=3398$ dyadic exponents.

## The pair and its verification

Use the PPI-PU1 rational annihilating profile and its dyadic-anchor blend on $H$, with the parameters $K,c,\delta$ just specified. The checker verifies the free error including the blend is below $2\delta/5$, that $0<c-R\delta\le c<2$, and that $Kw$ is on the required dyadic grid by the PPI-PU1 denominator bounds. Thus the normalized free mass $Kw/2$ lies inside the checked interval $n+b+ls\pm2s/5$. Both sets take the decoded section on free orders, full sections on strict lower orders and empty sections on strict upper orders. On the signed support they take opposite full and empty sections, the first set full at positive sign. The forced comparisons follow from order convexity and consistent signs on comparable support orders. Comparable free orders at different ranks respect nesting, and comparable equal-rank orders have the same profile by PPI-PU1. This proves that both indicators $f,g$ define subgroup unions.

Their section-size profiles on $H$ are even and distinct. A translation by $a$ between these profiles would make $2a$ a period, and thus $a$ a period since $H$ has odd order, contradicting distinctness. Finally $f-g=e$ on every fiber and the sum of $f+g$ on that fiber is $|S|w$. Since the sets are even, at each labeled shift $(z,y)$ their autocorrelation difference is $((f-g)*(f+g))(z,y)=|S|(e*w)(z)=0$.

Run **python3 experiments/ppi_weighted_digits.py** with assertions enabled. The expected damping digest is 23e5252c352377b5fc2c291df5f491d1f66fc88f7e4316dbb10b66822fee5f28. All interpolation, primality, mass and decoding checks replay in exact arithmetic. The at-most-100 objective and independent referee review remain open.

## What the present error estimate would require at 100 primes

**PPI-WD3.** With the 49 fixed axes, the same two-prime damping rule and the present uniform error envelope, reaching the $2\delta/5$ window requires at least 20 damping blocks regardless of spectator design. Write $U,L$ for the two individual norm bounds passed to verify_templates, $B_*=(1+U)(3+L)/4$, and $R_t=45+2t$. The envelope before the dyadic blend contains
\[
2^{-t}\bigl(B_*+\tfrac32 R_t\delta(1+U)(1+L)\bigr).
\]
Since $0<c-R_t\delta\le c<2$, one has $1/\delta>R_t/2$. Dividing by $\delta$ gives a strict lower bound $2^{-t} R_t (B_*/2+\tfrac32(1+U)(1+L))$ on this envelope in step units. The verifier checks it exceeds $2/5$ for every $0\le t\le19$. Thus at most 11 odd primes would remain for a spectator under a 100-prime budget using this estimate. The conclusion is about this certificate inequality. It gives no lower bound for arbitrary annihilating profiles.
