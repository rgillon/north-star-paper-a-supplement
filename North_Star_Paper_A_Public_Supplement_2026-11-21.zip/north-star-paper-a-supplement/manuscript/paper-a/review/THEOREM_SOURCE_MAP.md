# Paper A: theorem and source map

**Review documentation dated 21 November 2026.** This map describes the actual statements and TeX labels of the revised manuscript. The numerical theorem references follow the manuscript's section numbering. Source labels are also supplied so that a later layout change does not obscure the correspondence.

The original construction source is pinned to `09d77232d96df1e16ef52917ddf46ccff90deb0b`. The complete later support baseline is `2ddc150f363da5ae410ed4ac1de573e7cbd7bb80`. The revised manuscript and new review records accompany that baseline. The second pin, rather than the first, supplies the additional audit programs and graph-control package. A passing computational check has the scope stated below; it is not a Lean declaration or a substitute for the corresponding universal argument.

## 1. Main theorem and graph theory

In this table, “proof” identifies the mathematical dependency, while “control” identifies a separate finite check. All paths are relative to this document.

| Manuscript statement | TeX source and label | Mathematical dependency and computational support |
| --- | --- | --- |
| **Theorem 1.1:** two subgroup unions with equal labeled autocorrelation, not translates, at the specified \(2^{3446}M_{100}\) | Statement: [01-question.tex](../01-question.tex), `vi:th:main`. Proof: end of Section 12 in [05-construction.tex](../05-construction.tex). | Lemma 8.1 and Sections 9–12. Finite input: [manifest](../../../experiments/ppi_100_certificate.json), [ordinary-slot permutation](../../../experiments/ppi_100_slot_order.json), and donor data. Replays: the three H100 programs listed in §3 below. No graph enumeration at the constructed modulus is required. |
| **Lemma 2.1:** subgroup unions are exactly increasing binary valuation profiles | [02-sign-graph.tex](../02-sign-graph.tex), `ii:lem:upset` | Principal upper sets are subgroup profiles. This translates between subgroup unions and the finite product-of-chains order. |
| **Lemma 2.2:** integral conductor inversion | Same file, `ii:lem:integrality`; equations `ii:eq:alpha`, `ii:eq:Fs`, `ii:eq:inversealpha` | Möbius inversion, subgroup character sums, and coprime prime-power divisibility. The adjacent congruences are sufficient as well as necessary. Relation to cyclic Burnside marks: Remark `ii:rem:burnside`. Control: `verify_p004.py`. |
| **Theorem 3.1:** exactly \(2^{u_{\rm rad}}\) radial binary mates | Same file, `ii:thm:radial`; edge rule `ii:eq:edge` | Lemma 2.2 gives integral inverses after component flips. Fixed mass plus Parseval forces binary values. Control: `verify_radial_generalization.py`, with separate orbit checks below. |
| **Proposition 4.1:** odd-order symmetric binary uniqueness | Same file, `ii:prop:odd` | Convolution modulo 2 and bijectivity of doubling on an odd cyclic group. Its comparison class is symmetric binary sets, not arbitrary binary sets. |
| **Proposition 4.2:** translation/complementation masks and orbit count | Same file, `ii:prop:symmetries`; equation `ii:eq:orbitcount` | Fourier support determines periods; the relevant translation is half the least period. Complementation is homometric only at half size. Control: `verify_symmetry_reduction.py`. |
| **Lemma 5.1:** pure-prime Fourier nonnegativity for subgroup unions | Same file, `ii:lem:pure` | Monotone primary fibers telescope into nonnegative subgroup-indicator combinations. Fixed magnitudes therefore fix all pure-prime signs. |
| **Lemma 5.2:** fixed primary marginals and autocorrelation recover increasingness | Same file, `ii:lem:defect`; equations `ii:eq:marginal`, `ii:eq:shellcorr`, `ii:eq:defect` | A nonnegative shell defect vanishes. Binary values and positive shell weights force each primary fiber to be increasing. The argument includes \(p=2\). |
| **Theorem 5.3:** exactly \(2^{u_{\rm div}}\) subgroup-union mates; rigidity iff \(u_{\rm div}=0\) | Same file, `ii:thm:subgroups` | Theorem 3.1 plus Lemmas 5.1–5.2. Controls: initial graph checks and extended conductor/anchoring checks. This is a classification for a specified target, not a prime-factorization criterion for its modulus. |

All graph-control programs named here are supplied under [graph-controls/](../graph-controls/). Theorem 3.1 permits more mates than Theorem 5.3 because radiality alone does not impose subgroup-union closure.

## 2. Rigid families, examples, and consequences

| Manuscript statement | Source and label | Scope and dependency |
| --- | --- | --- |
| **Proposition 6.1:** rigidity at \(C_{2M}\), \(M\) odd | [03-boundaries.tex](../03-boundaries.tex), `vi:prop:twice` | Primary section parity fixes singleton sections; a minimal differing odd order gives the contradiction for the remaining sections. |
| **Proposition 6.2:** rigidity at \(C_{4M}\) with at most one distinct prime divisor of \(M\) congruent to 3 modulo 4 | Same file, `prop:four` | Section parity and a mod-4 shell argument. The prime restriction is part of the theorem, not a computational convenience. |
| **Proposition 6.3:** a translated single subgroup reflection cannot produce a distinct subgroup union | Same file, `bridge:separation` | Period quotient and pure-primary spectral positivity. In particular, distinct subgroup unions cannot be translates. This is not a classification of arbitrary reflection compositions. |
| **Examples 7.1 and 7.2:** radial ambiguities at 12 and 24 | [04-small-examples.tex](../04-small-examples.tex), `ii:ex:12`, `ii:ex:24` | Explicit Fourier tables and graph flips. The nontrivial companion in Example 7.2 is not a subgroup union. These do not contradict Theorem 5.3 or the rigid-family results. |
| **Corollary 7.3:** graph certificate in \(O(hL)\) integer arithmetic operations | Same file, `ii:cor:certificate` | Product-of-chains differences/cumulative sums and adjacent graph edges, with \(h=\omega(N)\), \(L=\tau(N)\). This is not a bit-complexity estimate or a bound for printing exponentially many mates. |
| **Corollary 7.4:** prime-power and odd-order rigidity | Same file, `ii:cor:primepower` | Prime-power subgroup unions form a chain and are determined by size; odd-order assertion follows from Proposition 4.1. |
| **Corollary 13.1:** nonrigidity is closed under multiples | [05-construction.tex](../05-construction.tex), `vi:cor:lift` | Pullback under reduction satisfies \(C_{\pi^{-1}A}(t)=kC_A(\pi t)\). Together with Propositions 4.1 and 6.1 this gives an upper interval of nonrigid dyadic heights beginning at least at 2. |
| **Corollary 13.2:** an intersection step can destroy unique reconstruction | Same file, second corollary in Section 13; no explicit TeX label | Express exclusion of each minimal missing element order as a union of subgroups of pairwise coprime prime-power indices; take the first nonunique prefix. Uses Theorem 1.1 and uniqueness of the full group. |
| Threshold observations and open questions | Same file, final paragraphs of Section 13 | \(M\mid M'\Rightarrow h(M')\le h(M)\), and \(2\le h(M_{100})\le3446\). The general \(4M\) problem, least modulus/height, and arithmetic classification remain open. The separate six-factor draft is not used. |

## 3. H100 proof obligations and exact data

Every construction section below is in [05-construction.tex](../05-construction.tex). Equation labels identify the intended formula even if its displayed number changes.

| Obligation | Manuscript location | Data, program, or review entry point |
| --- | --- | --- |
| Signed support geometry, divisor closure, all-shift homometry, and nontranslation | **Lemma 8.1**, `vi:lem:sections` | The section table and convolution identity are the universal proof. No sampled target replay establishes this lemma. |
| Upper donor fibers, conductor cancellations, incidence minor, and packet boundary values | **Section 9**, `h100:upper-fibres`, `h100:upper-transform`, `h100:upper-witness` | [ppi_unbalanced_pair.py](../../../experiments/ppi_unbalanced_pair.py); independent audit extracts literal data and solves/evaluates it separately. |
| Lower donor, denominator, and norm | **Section 9**, “The lower donor” | [ppi_weighted_fibers.py](../../../experiments/ppi_weighted_fibers.py), `LOWER`; independent exact incidence and packet evaluation. |
| Three two-prime corrections and sharper upper bound | **Section 9**, `h100:partial-bound`, `h100:individual-bounds` | [ppi_partial_upper_pair.py](../../../experiments/ppi_partial_upper_pair.py) and dependent donor modules; independent arithmetic audit recomputes successive norm bounds. |
| Helper primality, odd-denominator removal, dyadic anchors | **Section 9**, “Dyadic anchors from two modular helpers”; `h100:anchor-exponents` | [ppi_modular_pair.py](../../../experiments/ppi_modular_pair.py) and independent audit. The latter retains Pocklington factor/modular witnesses for the eight large helpers. |
| Balanced damping, rank \(R=86\), comparable equal-rank invariance | **Section 9**, “Damping and rank”; `h100:rank-bound` | `PAD_PRIMES` in [ppi_100_prime_pair.py](../../../experiments/ppi_100_prime_pair.py). Invariance is a symbolic argument using the actual order/packet convention. |
| Annihilation, exact forced values, rational and dyadic error bounds | **Section 9**, `h100:product-interpolation`, `h100:rational-profile`, `h100:rational-error`, `h100:final-profile` | Universal product-subtraction and grouped moving-upper argument; exact audit fields `rational_error_over_delta`, `blend_error_over_delta`, `total_error_over_delta` in `exact_rationals`. |
| All-target denominator bound | **Section 9**, `h100:fine-precision` | Symbolic denominator accounting; audit checks the numerical exponents. \(Kw/(2M)\) has bound 3347; the chosen fine-grid precision is 3353. |
| Tags, full background, ordinary/fine slots, exact masses and cover relations | **Section 10**, `h100:spectator`, `ordinary-slots`, `fine-slots` | Manifest and slot permutation; `ppi_100_prime_pair.py`; [ppi_h100_decoder_audit.py](../../../experiments/ppi_h100_decoder_audit.py). Hidden-fiber and tag indices use different declared orderings. |
| Every section is a divisor ideal; all-choice nesting across levels | **Section 11**, `h100:nesting` | Universal height-comparison argument; decoder audit checks finite cover and physical-height hypotheses. |
| Every admissible target mass is realizable | **Section 12**, `h100:mass` | Universal interval, greedy residual, grid, and odd-weight parity arguments. The 435 original and 2,175 audit target replays are corroboration. |
| Prime-power map, prime budget, ambient height, and size | End of **Section 12** | [ppi_100_certificate.json](../../../experiments/ppi_100_certificate.json) and [ppi_h100_independent_audit.py](../../../experiments/ppi_h100_independent_audit.py); 92 trial-divided small primes and 8 Pocklington-certified helpers. |

The historical [PPI_100_PRIME_PAIR.md](../construction-proofs/PPI_100_PRIME_PAIR.md) is a useful longer construction record. Its historical status language and commands must be read with its own provenance. The current manuscript and [Appendix A](../06-reproduction.tex) give the review-package conventions and exact replay commands.

## 4. Computational records and their limits

| Record or entry point | What it supports |
| --- | --- |
| [Fresh reproducibility report](replay/REPRODUCIBILITY_REPORT.md) and [summary](replay/REPLAY_SUMMARY.json) | Fresh command results, environments, source identities, and explicit replay scope. |
| [Canonical H100 source inventory](replay/canonical_h100_source_inventory.json) | Exact identities of the root `experiments/` sources used in replay. |
| [Original H100 output](replay/h100_canonical_original.stdout.log) | Original certificate replay, including 435 targets over 87 levels. |
| [Independent arithmetic output](replay/h100_canonical_independent.stdout.log) | Recomputed finite arithmetic and exact error fractions. Rational / blend / total normalized bounds are respectively 0.2534210321432835…, 0.0005089276015204947…, and 0.2539299597448040…. |
| [Independent decoder output](replay/h100_canonical_decoder.stdout.log) | Spectator covers, slot ranges, and 2,175 exact target replays. |
| [verify_p004.py](../graph-controls/verify_p004.py) and [fresh initial-domain result](replay/graph_first_domain_fresh.json) | Initial 18-modulus graph controls; 2,183 subgroup-union profiles, including full-shift checks for the stated domain. |
| [replay_graph.cpp](../graph-controls/replay_graph.cpp), [modulus list](../graph-controls/replay_moduli.txt), [fresh output](replay/graph_cpp_38.stdout.log) | Exact profile and unanchored-target counts at all 38 moduli. It does not enumerate every ambient shift or report every component count. |
| [verify_extended_subgroups.py](../graph-controls/verify_extended_subgroups.py) and [recorded results](../graph-controls/extended_subgroup_results.json) | Optional NumPy/Numba extended implementation and recorded counts. The fresh C++ replay covers all 38 moduli; a fresh run of the optional implementation is not claimed. |
| [Radial verifier](../graph-controls/verify_radial_generalization.py) and [symmetry verifier](../graph-controls/verify_symmetry_reduction.py) | Separate finite checks of Theorem 3.1 and Proposition 4.2, with fresh receipts in `replay/`. |
| [Lean status report](lean/LEAN_VERIFICATION_REPORT.md), [inventory](lean/lean_inventory.json), and [inventory script](lean/inspect_lean_artifacts.py) | Scoped search found no supplied replayable Lean project. No Lean build or axiom audit was performed. The script inventories artifacts; it is not a proof checker. |

The current mathematical claim rests on the stated proofs and finite certificate obligations together. Neither the control counts nor the absence of a Lean project resolves the open arithmetic classification problem.
