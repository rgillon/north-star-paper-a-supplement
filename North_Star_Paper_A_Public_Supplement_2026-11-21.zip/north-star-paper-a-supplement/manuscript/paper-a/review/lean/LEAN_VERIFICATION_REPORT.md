# Lean verification status and scope

**Paper:** Robert Gillon, *Reconstructing Unions of Subgroups from Cyclic Autocorrelation*, 100-odd-prime revision.  
**Audit date:** 21 November 2026.  
**Status:** No replayable Lean formalization located in the inspected sources. No Lean build was performed.

## 1. What this report establishes

The manuscript's proof and its exact computational checks should be evaluated on their own stated evidence. **This review package does not certify Theorem 1.1, the sign-graph classification, or any other Paper A theorem as Lean-verified.**

This is a report of the formal-verification status, not a successful formal-verification certificate. No Lean source was generated merely to wrap the manuscript's conclusions in unproved assumptions, and no uncompiled prototype is presented as a proof.

## 2. Evidence inspected

The audit inspected complete recursive GitHub tree inventories at three exact repository revisions:

| Source in rgillon/north-star-math | Revision inspected | Tree listing | Lean project artifacts |
| --- | --- | --- | --- |
| Current manuscript-revision baseline | `2ddc150f363da5ae410ed4ac1de573e7cbd7bb80`; tree `c4e0af7df057487dcb3f5f4a61be825c34d1b0d6` | 1,209 entries; not truncated | None found |
| Main | `71be4db6c51b11ead8d0abe6c815361d294482ba` | 743 entries; not truncated | None found |
| Collaboration-notes branch | `95c0529967f4ff8ba7b812b9377f20283e4240dd` | 971 entries; not truncated | None found |

The inventory looked for Lean source files, Lean toolchain declarations, Lake project configuration and manifests, and named formalization artifacts. The local repository mirror likewise contained no Lean project. No Lean, Lake, or Elan executable was available on PATH in the audit environment.

A bounded search of the author's available document collection did not locate a Paper A Lean report. The historical document titled *Verification_Report.md* concerns Manuscript IV, *A Complete Homometry Classification for Pairwise-Coprime Divisibility Generators*. It explicitly distinguishes its mathematical reconstruction and exact finite computations from formal proof certification. It is therefore not evidence of a Lean formalization of Paper A.

These are scoped findings. They do not assert that no Lean file could exist in any uninspected branch, private workspace, or unpublished archive.

## 3. Coverage of the current manuscript

| Paper A component | Replayable Lean theorem supplied or located? | Lean build in this audit |
| --- | --- | --- |
| Integral conductor inversion, Lemma 2.2 | No | Not run |
| Radial sign-graph classification, Theorem 3.1 | No | Not run |
| Subgroup-union rigidity criterion, Theorem 5.3 | No | Not run |
| Odd-order and twice-odd rigidity | No | Not run |
| Restricted four-times-odd rigidity, Proposition 6.2 | No | Not run |
| Section construction criterion, Lemma 8.1 | No | Not run |
| Donor interpolation and arithmetic bounds | No | Not run |
| Nested binary realization and all-shift homometry | No | Not run |
| Explicit 100-odd-prime counterexample, Theorem 1.1 | No | Not run |

There is consequently no meaningful count of successfully checked Paper A Lean theorems, no Lean axiom audit, and no Lean build log to attach. An empty file inventory must not be advertised as a successful zero-placeholder audit.

## 4. Exact computation and formal proof are different evidence

The supplied Python and C++ programs can recompute integer or rational identities, inspect finite families, and check numerical certificates. Their exact arithmetic avoids numerical-rounding issues, but a successful run does not by itself prove in Lean that the programs implement the intended mathematical statements or that the manuscript's universal deductions are valid.

A Lean formalization would state the mathematical objects and claims in the proof assistant, construct proofs from specified definitions and dependencies, and check those proofs. The official Lean documentation explains this proof-object approach and separately discusses the role of axioms and computational evaluation.[1,2]

The relevant distinctions are:

- A test over sampled targets supports the tested cases.
- A mathematically proved interval/grid argument can establish the universal realization step without enumerating every target.
- A Lean formalization of that universal argument would be an additional, distinct verification layer.

The current revision supplies the first two forms of evidence at their documented scopes. This report does not claim the third.

## 5. A useful formalization sequence

The following is a proposed work plan, not implemented Lean coverage.

**First target: the section criterion and convolution identity.** Formalize integer-valued functions on finite cyclic groups, indicators, and convolution. Prove the identity connecting the difference of autocorrelations to the convolution of the difference and sum for the even indicators used in Paper A. Then formalize the forced support values and nesting conditions in Lemma 8.1. This would check the bridge from an annihilating common-section profile to actual binary subgroup unions.

**Second target: the nested realization theorem.** Formalize the ordinary and fine digit constructions, exact interval and grid hypotheses, and the divisibility nesting of decoded sections. The target should quantify over every admissible target, rather than encode only the finitely many replayed values.

**Third target: conductor inversion and the graph theorem.** Formalize the divisor lattice, integral conductor transforms, sign compatibility, and the implication from the anchored-component conditions to divisor-closed mates. The converse and exact mate count need their own explicit theorem statements.

**Fourth target: the H100 certificate and assembly.** Import the finite prime and slot data through a specified parser or native definitions; prove the soundness of the arithmetic certificate checker; prove the required primality, disjointness, denominator and interval facts; then instantiate the section and realization theorems. This approach should avoid enumerating the enormous ambient cyclic group.

These targets have different costs. A proof of one identity or a finite prime certificate would not constitute a formalization of Theorem 1.1. The exact coverage should be reported theorem by theorem.

## 6. What a future successful Lean report should include

A reproducible formal-verification release should provide:

1. The Lean source, pinned toolchain, pinned mathematical-library dependencies, and an exact clean-build command.
2. A map from each manuscript statement to its formal declaration, including all hypotheses and comparison classes.
3. A clean build log tied to the source revision.
4. A dependency and axiom audit for the final declarations, including the output of Lean's axiom-reporting facility.
5. An explicit account of admitted proofs, custom assumptions, and any trusted computation boundary.
6. The soundness argument connecting any imported certificate data and its checker to the formal mathematical conclusion.

Ordinary declared foundational axioms and an unproved assumption asserting the target theorem are different matters. The report should expose the dependency set so a reviewer can assess that distinction.[2]

## 7. Suggested statement for the manuscript

> The supplementary programs provide exact computational checks and reproducible numerical certificates. The arguments in this paper have not been certified by a supplied Lean formalization. The accompanying formal-verification status report records the inspected source revisions and the present coverage.

This accurately describes the current package without weakening or overstating the separate mathematical proof.

## References

[1] *Theorem Proving in Lean 4*, Chapter 1, “Introduction,” especially Section 1.1, “Computers and Theorem Proving.” Official Lean documentation, accessed 21 November 2026.  
https://lean-lang.org/theorem_proving_in_lean4/Introduction/

[2] *Theorem Proving in Lean 4*, Chapter 12, “Axioms and Computation,” including the discussion of axiom dependencies. Official Lean documentation, accessed 21 November 2026.  
https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/

**Accompanying evidence:** lean_inventory.json records the scoped repository and environment observations. inspect_lean_artifacts.py reproduces the local artifact inventory only; it does not run Lean or validate a mathematical proof.
