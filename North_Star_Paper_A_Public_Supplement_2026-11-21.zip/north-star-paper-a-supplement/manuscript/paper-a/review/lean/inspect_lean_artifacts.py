#!/usr/bin/env python3
"""Inventory formalization artifacts. This is not a Lean proof checker."""
from pathlib import Path
import argparse
import json
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("root", type=Path, help="Repository or review-package root")
args = parser.parse_args()
root = args.root.resolve()
if not root.is_dir():
    raise SystemExit(f"Not a directory: {root}")

configs = {"lean-toolchain", "lakefile.lean", "lakefile.toml", "lake-manifest.json"}
source = []
configuration = []
compiled = []
for path in sorted(root.rglob("*")):
    if not path.is_file():
        continue
    rel = path.relative_to(root)
    if any(part in {".git", ".lake", "__pycache__"} for part in rel.parts):
        continue
    if path.suffix == ".lean":
        source.append(str(rel))
    if path.name in configs:
        configuration.append(str(rel))
    if path.suffix == ".olean":
        compiled.append(str(rel))

result = {
    "inventory_only": True,
    "proof_checked": False,
    "build_status": "NOT_RUN",
    "root": str(root),
    "lean_source_files": source,
    "project_configuration_files": configuration,
    "compiled_olean_files": compiled,
    "executables_on_PATH": {name: shutil.which(name) for name in ("lean", "lake", "elan")},
    "excluded_dependency_or_internal_directories": [".git", ".lake", "__pycache__"],
    "scope": "Artifact inventory only; absence is scoped to this root, and presence would not by itself prove a theorem.",
}
print(json.dumps(result, indent=2))
