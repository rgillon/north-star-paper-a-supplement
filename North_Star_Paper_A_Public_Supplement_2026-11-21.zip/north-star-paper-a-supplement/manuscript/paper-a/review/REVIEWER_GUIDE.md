# Reviewer guide to Paper A

**Robert Gillon, _Reconstructing Unions of Subgroups from Cyclic Autocorrelation_**  
**100-odd-prime revision; review documentation dated 21 November 2026**

This guide separates the paper's mathematical deductions, finite arithmetic certificates, and computational controls. It is an aid to reviewing the manuscript, not an additional referee verdict. The [theorem and source map](THEOREM_SOURCE_MAP.md) identifies the exact source locations and supporting programs.

## 1. What the paper establishes

The paper has two principal results. Theorem 5.3 classifies every subgroup-union mate of a **specified** subgroup union by sign choices on its Fourier graph. Theorem 1.1 constructs two subgroup unions with identical autocorrelation at every labeled cyclic shift, in different translation orbits, at

\[
N=2^{3446}M_{100}.
\]

The odd part has exactly **100 distinct prime factors**, with repeated prime powers permitted and used. Thus the full modulus has 101 distinct prime factors. The manifest determines an integer of 8,123 bits and 2,446 decimal digits. No minimality of this modulus, dyadic height, or prime count is asserted. See [Section 1](../01-question.tex), the assembly at the end of [Section 12](../05-construction.tex), and the [manifest](../../../experiments/ppi_100_certificate.json).

For a short first reading, inspect Theorem 5.3 and its two supporting lemmas, then Lemma 8.1 and the final assembly of Theorem 1.1. The former explains exactly what an ambiguity is; the latter explains why a signed annihilator and realizable common sections produce genuine subgroup unions. Sections 9–12 supply those hypotheses. The graph classification and the construction have separate proofs: the construction does not depend on enumerating the graph of the enormous example.

## 2. Conventions that matter

| Notation or convention | Meaning and review consequence |
| --- | --- |
| \(C_A(t)=\sum_x1_A(x)1_A(x+t)\) | The full function of the **labeled** shift \(t\) is specified. Equality is not merely equality of an unlabeled multiset of correlation values. |
| \(d\mathbb Z_N\) in Section 1 | Here \(d\mid N\) is the subgroup **index**. An element-order divisor elsewhere has a different role. |
| Valuation profile in Section 2 | The capped residue valuation is \(r_i=\min(a_i,v_{p_i}(x_i))\). A subgroup-union profile is binary and **increasing** in \(r\). |
| Element-order profile in Sections 8–12 | An order is \(\prod p_i^{v_i}\), where \(v_i=a_i-r_i\). A subgroup union is **downward closed** in the divisibility order on these orders. The change reverses the coordinate order. |
| Fourier normalization | The transform and convolution are unnormalized. Fourier inversion carries \(1/N\). A conductor \(c\) represents \(\varphi(c)\) characters, which must be retained in Parseval. |
| Radial versus subgroup union | Radial means constant on residue-valuation shells. Radial binary functions need not be increasing. Theorem 3.1 and Theorem 5.3 consequently have different comparison classes. |
| \(D,U,P\) in the construction | These can denote shell families or their indicators. Set intersection corresponds to pointwise multiplication: \(D\cap U=P\), or \(DU=P\) for indicators. It is not a sumset or convolution identity. |
| \(w\) and \(J_x\) | A common section \(J_x\subseteq S\) has density \(w(x)/2\). The sum of the two section sizes is \(|S|w(x)\); \(w\) is not itself a binary indicator. |

There is one particularly consequential packet convention. In a coordinate \(C_{p^a}\), an element of order \(p^v\) is divisible by \(p\) precisely when \(v\le a-1\). Thus the bit in

\[
t_T(x)=\prod_{i\in T}\bigl(1-p_i1_{\{p_i\mid x_i\}}\bigr)
\]

is the **complement of the full-order indicator**, not the indicator that the element order is nontrivial. Checking the stated coatom value 1 and full-order value 0 for the upper witness is a useful way to detect a convention mismatch. Also distinguish the conductor transform \(F(s)\) in Sections 2–5 from the product-interpolation expression \(F(X)\) in Section 9; the symbol is reused.

## 3. The graph proof: integrality, binary values, and closure

The dependency chain in [Sections 2–5](../02-sign-graph.tex) is short enough to review independently of the construction.

**Integral inversion.** Lemma 2.2 expands an integer radial function in subgroup indicators. Its conductor coefficients satisfy adjacent prime-power congruences. Conversely, the mixed finite-difference numerator is divisible by the required power of each distinct prime, hence by their product. This is the point that excludes additional hidden mixed-coordinate integrality constraints. The manuscript identifies its relationship to cyclic Burnside marks and makes no novelty claim for the underlying mark-image characterization.

**All radial binary mates.** Theorem 3.1 puts a vertex at each nonzero Fourier coefficient. An adjacent pair has an edge when opposite signs would violate the local congruence. Any component sign choice preserving the root therefore has an integer radial inverse. Its total mass and squared norm both equal \(|A|\), so

\[
\sum_x b(x)(b(x)-1)=0.
\]

For integer \(b(x)\), every summand is nonnegative, forcing binary values. This argument uses both integrality and the \(\varphi(c)\) conductor multiplicities. Zero Fourier entries are omitted as vertices but treated explicitly in the congruence proof. The result is exhaustive, not merely a method for generating some mates.

**Recovering subgroup-union closure.** Lemma 5.1 proves nonnegativity at pure prime-power conductors, so those signs cannot change for subgroup-union mates. Lemma 5.2 proves the converse closure implication: fixed pure-primary marginals and fixed autocorrelation make a nonnegative shell defect vanish. Its summands prohibit a fiber value 1 below a fiber value 0 in valuation coordinates. Applying this on every primary factor recovers increasingness, including at the prime 2.

These steps prove Theorem 5.3: the allowable components contain neither the root nor a pure prime-power conductor, and there are exactly \(2^{u_{\rm div}(A)}\) subgroup-union mates. Proposition 6.3 additionally separates distinct subgroup unions into distinct translation orbits. Proposition 4.2 has a different purpose: it computes translation/complementation identifications among the larger class of radial mates.

## 4. The construction proof: from a signed trade to actual sets

### The reusable bridge

Lemma 8.1 starts with an odd cyclic factor \(H\), a coprime cyclic section factor \(S\), and a nonzero signed order-shell function \(e\). Its support must be order-convex in the stated closure sense, with the same sign at comparable support orders. The strict lower region has full sections in both sets, the strict upper region has empty sections, and the signed support has opposite full/empty sections. On the remaining incomparable orders the two sets share \(J_x\).

Closure follows from the support geometry and the inclusions \(J_{x'}\subseteq J_x\) when \(x\mid x'\). The precise cancellation is

\[
C_A(z,t)-C_B(z,t)=|S|(e*w)(z).
\]

It proves equality at **every** shift once \(e*w=0\), without enumerating the ambient group. The nontranslation argument uses even section-size profiles and the odd order of \(H\). This lemma is the main bridge a reviewer should check before the numerical construction.

### Building the annihilator

Section 9 combines upper and lower donors, three two-prime corrections, modular helpers, and 20 balanced damping blocks. Finite incidence systems specify conductor packets annihilated by the signed discrepancy. Their solutions provide exact boundary values. Helpers clear odd denominators while maintaining annihilation; damping makes approximation error small enough for the section decoder.

The product-subtraction formula ensures every surviving summand contains an annihilating local factor. For the moving upper target, the current argument groups the upper block with its balanced helper. This avoids assuming that each two-prime correction has zero total: those corrections need not be balanced individually.

The rank \(r\) is increasing and bounded by \(R=86\). Comparable equal-rank orders preserve the relevant full-order/activity and closure bits, hence every profile input. This invariance is needed when the ranks agree; nesting across unequal ranks alone would not establish the required inclusions. The packet convention above is essential here.

### Realizing every required section

Sections 10–12 use twelve spectator primes and the dyadic factor of \(S\). The ordinary slots encode the large part of the section mass; fine slots encode a residual dyadic grid point. There are 614 ordinary slots and 3,840 available fine slots, of which 3,353 are used.

The universal argument has three parts. First, slot weights and height ranges ensure that **every** permitted choice is a divisor ideal. Second, every section at one level is contained in every section at the next larger level; comparable equal-rank orders use identical deterministic decoder inputs. Third, an interval argument, a greedy residual bound, and the backward parity recurrence on odd fine weights realize every admissible grid target. The first eight fine weights equal 1, and the remaining weighted tail is less than \(1/4\), completing the recurrence.

The denominator bounds put every actual target on that grid. The height budget is \(3353+86+7=3446\). These are universal deductions from checked finite inequalities, not extrapolations from the replayed targets. The final assembly verifies disjoint prime sets, cyclicity, and the budget \(48+40+12=100\).

## 5. Reading the numerical bounds correctly

The following are **upper bounds divided by \(\delta\)**, not attained pointwise errors. The [independent arithmetic output](replay/h100_canonical_independent.stdout.log) retains their exact numerators and denominators.

| Quantity | Decimal summary |
| --- | ---: |
| Rational-profile error bound from Section 9 | 0.2534210321432835… |
| Additional dyadic-blend error bound | 0.0005089276015204947… |
| Combined bound | 0.2539299597448040… |
| Final allowance \(1/m\), with \(m=7/2\) | 2/7 |

The older decimal 0.2539299597 describes the **combined** bound; it should not be substituted for the rational-profile term. The rational term is less than \(254/1000\); the separate blend estimate is less than \(1/(33m)\). Their sum is less than \(1/m\). The sharper upper-donor norm bound in the revision is needed to justify the stated rational estimate: the loose bounds \(\mathcal U<31\), \(\mathcal L<2447/1000\) alone do not give that intermediate constant. All decisive inequalities are checked as rational inequalities.

## 6. Source pins and replay

Two source pins serve different purposes:

- **Original construction:** `09d77232d96df1e16ef52917ddf46ccff90deb0b`.
- **Complete later support baseline:** `2ddc150f363da5ae410ed4ac1de573e7cbd7bb80`.

The later source includes the two audit programs and graph controls. Their presence is not asserted at the older pin. The review archive retains repository layout: `experiments/` at its root and graph controls under `manuscript/paper-a/graph-controls/`. Current manuscript changes and fresh replay receipts accompany those sources; historical proof records are not silently treated as newly issued verdicts.

From the archive root, with Python assertions enabled:

```sh
python3 experiments/ppi_100_prime_pair.py
python3 experiments/ppi_h100_independent_audit.py experiments
python3 experiments/ppi_h100_decoder_audit.py experiments
```

The first command needs SymPy; the two audits use the standard library and do not import the original verification routines. Consult the [fresh reproducibility report](replay/REPRODUCIBILITY_REPORT.md) for versions, input hashes, commands, outputs, and limitations. Appendix B supplies the graph replay commands.

The evidence has distinct scopes:

| Check | Coverage and limitation |
| --- | --- |
| H100 arithmetic audit | Exact donor systems, norms, primality certificates, modulus, intervals, and precision. The prose still supplies annihilation and construction arguments. |
| H100 decoder audit | Cover relations and physical slot ranges; 2,175 replayed targets across 87 levels. These supplement the all-target interval/grid proof. The original verifier replays 435 targets. |
| Initial graph controls | 2,183 subgroup-union profiles over 18 moduli, with exact full-shift autocorrelation checks for the stated domain. |
| Extended graph controls | A further 1,466,423 profiles over 20 moduli; exact conductor/anchoring checks. No separate full-shift enumeration is claimed for this extended domain. |
| Radial controls | 4,751 nonempty radial profiles and 9,817 component-flip instances, plus separate symmetry-orbit checks. |

None of these finite graph domains contains a subgroup-union counterexample. The construction supplies the nonrigid instance by proof. The fresh C++ replay confirms profile and unanchored-target counts, not a table of all graph-component counts.

## 7. Boundaries of the result and formal-verification status

Odd moduli and twice-odd moduli are rigid among subgroup unions. Proposition 6.2 additionally proves rigidity at \(4M\) when the odd part has at most one distinct prime divisor congruent to 3 modulo 4. Its hypothesis does not settle every \(4M\). Examples 7.1–7.2 illustrate extra **radial** mates; they are not smaller subgroup-union counterexamples.

Theorem 5.3 is an exact criterion for an individual set after its Fourier data are known. It is **not** an arithmetic classification of all moduli by prime factorization. The simultaneous binary, divisor-closed common-background feasibility problem remains open in the proposed elementary-trade research program. This revision neither establishes sufficiency of an arithmetic collision condition nor classifies every counterexample by a new prime-assignment rule.

Corollary 13.1 proves multiples closure and monotonicity of the threshold \(h(M)\), with \(2\le h(M_{100})\le3446\). Least height, least modulus, and the full arithmetic classification remain open. The separate six-factor draft is conditional background, unused in the proof.

No replayable Lean formalization was located in the inspected revisions, and no Lean build was performed. The [Lean status report](lean/LEAN_VERIFICATION_REPORT.md) records the search scope, theorem coverage, and useful formalization targets. Exact Python/C++ arithmetic, AI-assisted checking, external human peer review, and proof-assistant verification are different forms of evidence; this package does not equate them.
