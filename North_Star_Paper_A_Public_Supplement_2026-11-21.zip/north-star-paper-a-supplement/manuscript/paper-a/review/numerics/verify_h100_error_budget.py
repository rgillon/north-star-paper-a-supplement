#!/usr/bin/env python3
"""Recompute Paper A's H100 interpolation-error bounds using only exact arithmetic.

Input: directory containing the original ppi_*.py data files and certificate JSON.
No construction/verifier module is imported. The script reads literal tables with
ast.literal_eval, solves the two incidence systems by exact elimination, evaluates
all packet states, and reconstructs the partial-pair and blend bounds.

This is a targeted numerical derivation audit, not a formal proof of all of H100.
"""
import ast
from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
from math import gcd, lcm, prod
from pathlib import Path
import sys


def literals(path):
    values = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name):
                try:
                    values[target.id] = ast.literal_eval(node.value)
                except (ValueError, TypeError):
                    pass
    return values


def exact_solve(rows, rhs):
    n = len(rows[0])
    matrix = [[F(x) for x in row] + [F(y)] for row, y in zip(rows[:n], rhs[:n])]
    determinant = F(1)
    for col in range(n):
        pivot = next(i for i in range(col, n) if matrix[i][col])
        if pivot != col:
            matrix[pivot], matrix[col] = matrix[col], matrix[pivot]
            determinant *= -1
        value = matrix[col][col]
        determinant *= value
        matrix[col] = [x / value for x in matrix[col]]
        for i in range(n):
            if i == col:
                continue
            scale = matrix[i][col]
            matrix[i] = [x - scale * y for x, y in zip(matrix[i], matrix[col])]
    solution = [matrix[i][-1] for i in range(n)]
    assert all(sum(a * b for a, b in zip(row, solution)) == y for row, y in zip(rows, rhs))
    assert determinant.denominator == 1
    return solution, int(determinant)


def upper_values(primes, masks, coefficients, denominator):
    scaled = [int(denominator * c) for c in coefficients]
    assert all(denominator * c == v for c, v in zip(coefficients, scaled))
    indices = [[i for i in range(len(primes)) if mask >> i & 1] for mask in masks]
    constant = -sum(scaled)
    result = []
    for nonunit_mask in range(1 << len(primes)):
        result.append(constant + sum(
            scale * prod(1 - primes[i] if nonunit_mask >> i & 1 else 1 for i in selected)
            for scale, selected in zip(scaled, indices)
        ))
    assert result[0] == 0
    assert all(result[1 << i] == denominator for i in range(len(primes)))
    return result


def lower_norm(primes, masks, coefficients, denominator):
    selected = [[i for i in range(len(primes)) if mask >> i & 1] for mask in masks]
    scales = []
    for c, indices in zip(coefficients, selected):
        scale = denominator * c / prod(primes[i] - 1 for i in indices)
        assert scale.denominator == 1
        scales.append(int(scale))
    constant = -denominator * sum(coefficients)
    assert constant.denominator == 1
    vals = []
    for active in range(1 << len(primes)):
        vals.append(int(constant) + sum(
            scale * prod(-1 if active >> i & 1 else primes[i] - 1 for i in indices)
            for scale, indices in zip(scales, selected)
        ))
    assert vals[0] == 0
    assert all(vals[1 << i] == denominator for i in range(len(primes)))
    return F(max(map(abs, vals)), denominator)


def odd_part(n):
    return n // (n & -n)


def decimal(x, places=24):
    x = F(x)
    with localcontext() as context:
        context.prec = places + 10
        return format(Decimal(x.numerator) / Decimal(x.denominator), f".{places}f")


def record(x):
    x = F(x)
    return {"numerator": str(x.numerator), "denominator": str(x.denominator),
            "decimal": decimal(x)}


def ratio(U, L, delta, eta):
    return (((1 + U) * (3 + L) / 4 + (1 + L) * eta) / delta
            + F(3, 2) * 86 * (1 + U) * (1 + L)) / 2**20


def main():
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python verify_h100_error_budget.py EXPERIMENTS_DIRECTORY [OUTPUT_JSON]")
    source = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("h100_error_budget_result.json")
    names = ["ppi_unbalanced_pair.py", "ppi_weighted_fibers.py",
             "ppi_100_prime_pair.py", "ppi_100_certificate.json"]
    u = literals(source / names[0])
    lower = literals(source / names[1])
    h = literals(source / names[2])
    certificate = json.loads((source / names[3]).read_text())

    ps = [abs(row[0]) for row in u["FIBERS"]]
    masks = u["MASKS"]
    rows = [[(mask >> i) & 1 for mask in masks] for i in range(len(ps))]
    alpha, det_u = exact_solve(rows, [F(-1, p) for p in ps])
    assert det_u == 193
    du = det_u * prod(ps)
    values = upper_values(ps, masks, alpha, du)
    U0 = F(max(map(abs, values)), du)
    assert U0 < 602953959432

    # Packet convention: for shell order p^v in C_(p^a), x mod p=0 iff v<a.
    packet_checks = 0
    for (_, _, a, _) in u["FIBERS"]:
        for p in (3, 5):
            for v in range(a + 1):
                representative = 0 if v == 0 else p**(a - v)
                assert (representative % p == 0) == (v < a)
                packet_checks += 1

    signed, lmasks = lower["LOWER"]
    lp = list(map(abs, signed))
    rows = [[(mask >> i) & 1 for mask in lmasks] for i in range(len(lp))]
    beta, det_l = exact_solve(rows, [F(1 - p, p) for p in lp])
    dl = lcm(sum(beta).denominator, *(
        c.denominator * prod(p - 1 for i, p in enumerate(lp) if mask >> i & 1)
        for c, mask in zip(beta, lmasks)
    ))
    L = lower_norm(lp, lmasks, beta, dl)
    assert L < F(2447, 1000)

    U = U0
    corrections = []
    for p, q in u["PAIRS"]:
        Z = (p - 1) * (q - 1)
        bits = Z.bit_length() + 24
        scale = min(F(2 * Z, p + q - 2), U * (q - 1) / (U + q - 1))
        gamma = F((2**bits * scale) // Z, 2**bits)
        # Three nonzero physical orders: p, q, pq.
        deficits = [abs(1 - gamma * (q - 1)),
                    abs(1 - gamma * (p - 1)), gamma]
        updated = max(F(1), gamma * Z, U * max(deficits))
        corrections.append({
            "primes": [p, q], "bits": bits, "gamma": record(gamma),
            "bound": record(updated), "max_nonzero_deficit": record(max(deficits)),
        })
        U = updated
    assert [x["bits"] for x in corrections] == [64, 44, 34]
    assert U < F(6079, 200)

    k = (249391 * 2**32 * prod([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]) * du)
    upper_helpers = [1 + k * a for a in [2, 12, 3, 4]]
    o = odd_part(dl)
    P = upper_helpers[0]
    lower_helpers = [1 + P * (pow(P, -1, o) + j * o) for j in [304, 328, 170, 462]]
    manifest_primes = set(map(int, certificate["odd_prime_powers"]))
    assert set(upper_helpers + lower_helpers).issubset(manifest_primes)
    eta = F(1, min(lower_helpers) - 1)
    assert eta < F(1, 10**6)

    Q = prod(p**a for p, a in zip(h["TAGS"], h["POWERS"]))
    V = prod(p**a for p, a in zip(h["VARIABLE"], h["VARIABLE_POWERS"]))
    G = prod((p-1)*p**(a-1) for p, a in zip(h["TAGS"], h["POWERS"])
             if p in h["GUARDS"])
    common = odd_part(G)
    assert common == 83349
    K = Q * V // common
    assert Q * V == common * K
    s = F(int(certificate["step_numerator"]), 2**certificate["step_binary_exponent"])
    delta = 2 * s / K
    assert delta > F(1697, 10**7)

    rational = ratio(U, L, delta, eta)
    loose = ratio(F(31), F(2447, 1000), delta, eta)
    text_bound = ratio(F(6079, 200), F(2447, 1000), F(1697, 10**7), F(1, 10**6))
    assert rational < text_bound < F(253571, 10**6) < F(127, 500)
    assert loose > F(127, 500)

    E = odd_part(du * dl)
    lam = F(E * (2**367 // E), 2**367)
    Ustar, Lstar = U0 + 1, L + 1
    anchor_gap = 5 + 3 * (1 + Ustar) * (1 + Lstar)
    blend = (1 - lam) * anchor_gap / delta
    # A short printed derivation can use only these coarse integer bounds.
    assert E < 2**304
    assert 1 - lam < F(1, 2**63)
    assert anchor_gap < 8100000000000
    simple_blend_bound = F(81 * 10**18, 1697 * 2**63)
    assert blend < simple_blend_bound < F(2, 231)
    assert blend < F(2, 231)
    total = rational + blend
    assert total < F(2, 7)
    assert F(254, 1000) + F(2, 231) == F(30337, 115500) < F(2, 7)
    # The older Appendix A number is the COMBINED bound, not the rational bound.
    assert abs(total - F(2539299597, 10**10)) < F(1, 10**10)
    assert abs(rational - F(2534210321, 10**10)) < F(1, 10**10)

    result = {
        "status": "PASS",
        "scope": "Exact donor/error-budget derivation; no imported verifier functions; no full H100 proof claim.",
        "python": sys.version,
        "source_files": {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                         for name in names},
        "incidence": {"upper_minor": det_u, "lower_minor": det_l,
                      "all_extra_rows_checked": True},
        "packet_states": {"upper": len(values), "lower": 2**len(lp),
                          "upper_full_value": 0, "all_upper_coatoms": 1,
                          "lower_origin_value": 0, "all_lower_singletons": 1,
                          "coordinate_convention_checks": packet_checks},
        "upper_initial_bound": record(U0),
        "upper_final_bound": record(U),
        "lower_norm": record(L),
        "corrections": corrections,
        "delta": record(delta),
        "eta": record(eta),
        "odd_denominator_E": str(E),
        "E_bit_length": E.bit_length(),
        "lambda": record(lam),
        "anchor_difference_bound": record(anchor_gap),
        "displayed_blend_upper_bound": record(simple_blend_bound),
        "rational_error_bound_over_delta": record(rational),
        "blend_error_bound_over_delta": record(blend),
        "combined_error_bound_over_delta": record(total),
        "loose_U31_error_bound_over_delta": record(loose),
        "displayed_rational_upper_bound": record(text_bound),
        "displayed_conditions": {
            "U_lt": "6079/200", "L_lt": "2447/1000",
            "delta_gt": "1697/10000000", "eta_lt": "1/1000000",
            "result_lt": "253571/1000000 < 127/500",
        },
        "referee_decimal_disposition":
            "O-B6 corrected: 0.2539299597 is the reproduced combined bound; "
            "0.2534210321 is the rational-profile bound before blending.",
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "status": result["status"],
        "upper_final_bound": decimal(U),
        "lower_norm": decimal(L),
        "delta": decimal(delta),
        "rational_ratio": decimal(rational),
        "blend_ratio": decimal(blend),
        "combined_ratio": decimal(total),
        "safe_text_bound": decimal(text_bound),
        "safe_text_bound_fraction": str(text_bound),
        "safe_blend_bound": decimal(simple_blend_bound),
        "loose_U31_ratio": decimal(loose),
        "output": str(out.resolve()),
    }, indent=2))


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("Run with assertions enabled.")
    main()
