# H100 manuscript: mathematical and exposition corrections

**Scope:** targeted review for the November 21, 2026 revision of Paper A.
**Pinned source:** rgillon/north-star-math,
2ddc150f363da5ae410ed4ac1de573e7cbd7bb80.
**Status:** the mathematical and exposition corrections described here have been
applied to the November 21 manuscript; the grouped moving-upper formula and
all existing equation labels were preserved.
This is an exact numerical derivation and exposition check; it does not claim
an independent human review, Lean verification, or a fresh proof of every
statement in Paper A.

## 1. Main findings

1. The referee's derivation objection O-B7 is valid: substituting only
   U<31 and L<2447/1000 into the stated error expression does not prove
   the claimed rational-profile bound below 0.254.
2. The required repair is short. The actual recursive certified upper
   bound is
   \[
   U=30.394967524527532153925489\ldots<6079/200=30.395.
   \]
   This is a rigorous upward ceiling, not a rounded number accidentally
   below the true bound.
3. The referee's unexplained decimal O-B6 is now resolved by recovering
   the supplied audit data and independently reproducing the formulas:
   **0.2539299597 is the combined bound after blending.**
   It should not be replaced by the smaller rational-profile bound.
   Both components and their sum should be labeled explicitly.
4. The current pinned source already states the grouped moving-upper
   approximant in full. Preserve that formula. The packet convention
   should receive one explicit sentence in order coordinates.
5. The abstract source already contains a genuine superscript 2^u.
   Extraction flattening is not evidence of a typesetting error.

## 2. Exact independent computation

Run from the root of the review package, with Python assertions enabled:

~~~bash
python3 manuscript/paper-a/review/numerics/verify_h100_error_budget.py \
  experiments /tmp/h100_error_budget_result.json
~~~

The script imports no construction or audit module. It parses only literal
tables from four supplied source/data files, uses its own rational Gaussian
elimination for the incidence systems, evaluates all 65,536 upper packet
states and 16,384 lower packet states, verifies the forced packet values,
and recomputes the three partial-pair recurrences, spectator step, helper
flatness, blend coefficient, and error bounds.

Python 3.12.14, standard library only. Result: **PASS**.
Exact fractions and source SHA-256 values are retained in
h100_error_budget_result.json.

| Quantity | Exact-arithmetic decimal display |
| --- | --- |
| Final certified upper bound U | 30.394967524527532153925489... |
| Lower norm L | 2.446420082607105290597374... |
| delta | 0.000169785802366520766547... |
| Rational-profile bound divided by delta | 0.253421032143283461998513... |
| Blend bound divided by delta | 0.000508927601520494659597... |
| Combined bound divided by delta | 0.253929959744803956658110... |
| Substitution using loose U=31, L=2447/1000 | 0.258333212574204497484770... |
| Short printed rational upper bound below | 0.253570535111213756015038... |

The displayed error quantities are computed *bounds*. They are not claims
that the actual supremum of the profile error equals the displayed value.

## 3. A complete short derivation for the rational-profile bound

Retain the error expression
\[
B_{\rm rat}
=2^{-20}\left[
\frac{(1+U)(3+L)}4+(1+L)\eta+
\frac32R\delta(1+U)(1+L)
\right],
\qquad R=86.
\]

The defining tables and exact recurrences give
\[
U<\frac{6079}{200},\qquad
L<\frac{2447}{1000},\qquad
\delta>\frac{1697}{10^7},\qquad
\eta<10^{-6}.
\]

Here delta is 2s/K from the printed certificate and spectator formulas.
The eta bound is immediate from the lower-helper primes, and is very
conservative. All coefficients are positive, so monotone substitution gives
\[
\begin{aligned}
\frac{B_{\rm rat}}{\delta}
&<
2^{-20}\left[
\frac{
(1+6079/200)(3+2447/1000)/4
+(1+2447/1000)10^{-6}
}{1697/10^7}
 +129(1+6079/200)(1+2447/1000)
\right]\\
&=\frac{90242379537969}{355886694400000}\\
&<\frac{253571}{10^6}
<\frac{127}{500}
=\frac{254}{1000}.
\end{aligned}
\]

This closes the written derivation. It does not merely cite a passing
assertion or use the false inference from U<31.

### Suggested LaTeX for the norm paragraph

~~~latex
The successive precisions are 64, 44 and 34. Evaluating the three
nonzero orders in each block in \eqref{h100:partial-bound} gives
successive certified norm bounds below 776562, 882 and
$6079/200=30.395$. Denote the final upper witness by $u$, and the
original upper donor together with these three pairs by $A$.
Its discrepancy remains balanced, since the original upper donor
has total zero. We use the bounds
\begin{equation}\label{h100:individual-bounds}
 \|u\|_\infty\le\mathcal U<\frac{6079}{200},\qquad
 \|l\|_\infty\le\mathcal L<\frac{2447}{1000}.
\end{equation}
~~~

### Suggested LaTeX following the error expression

~~~latex
The exact spectator constants give
$\delta>1697/10^7$, and the lower-helper primes give
$\eta<10^{-6}$. Substituting these bounds and
\eqref{h100:individual-bounds} into
\eqref{h100:rational-error}, using $R=86$, gives the
following strict upper bound for its right-hand side divided by $\delta$:
\[
 \frac{90242379537969}{355886694400000}
 <\frac{253571}{10^6}<\frac{254}{1000}.
\]
The comparison uses rational arithmetic; the exact unrounded
bound is approximately $0.2534210321432835$.
~~~

## 4. An elementary written blend bound

Let
\[
E=\operatorname{oddpart}(d_ud_l),\qquad
\lambda=\frac{E\lfloor2^{367}/E\rfloor}{2^{367}}.
\]
The exact integer E has bit length 304. Therefore
\[
0\le1-\lambda<\frac E{2^{367}}<2^{-63}.
\]

The anchor construction gives
\[
\mathcal U_*\le\|u_0\|_\infty+1<602953959433,
\qquad
\mathcal L_*\le L+1<3447/1000.
\]
Consequently
\[
5+3(1+\mathcal U_*)(1+\mathcal L_*)<8.1\cdot10^{12}.
\]
With the same delta lower bound,
\[
\frac{(1-\lambda)
[5+3(1+\mathcal U_*)(1+\mathcal L_*)]}{\delta}
<
\frac{81\cdot10^{18}}{1697\cdot2^{63}}
<
\frac2{231}
=\frac1{33m},
\qquad m=\frac72.
\]
The middle rational is approximately 0.005175036887. The exact blend
bound is much smaller, approximately 0.0005089276015205.

Finally,
\[
\frac{254}{1000}+\frac2{231}
=\frac{30337}{115500}
<\frac27=\frac1m.
\]
This supplies the stated final window inequality using only explicit
rational comparisons and elementary floor bounds.

## 5. Correct disposition of the Appendix A decimal

The source sentence says **combined interpolation-error bound**. It
corresponds to
\[
\frac{B_{\rm rat}}{\delta}
+\frac{B_{\rm blend}}{\delta}
=0.253929959744803956658110\ldots,
\]
which agrees with the original 0.2539299597 to its displayed precision.
The recovered independent-audit script and the fresh standalone calculation
both reproduce it.

Thus the proper revision is to distinguish all three quantities, not
silently replace a valid total with its first summand.

### Suggested replacement Appendix A text

~~~latex
The exact bound from \eqref{h100:rational-error}, divided by
$\delta$, is approximately $0.2534210321432835$.
The additional blend bound, also divided by $\delta$, is
approximately $0.0005089276015205$.
Their combined bound is approximately $0.2539299597448040$,
strictly below $2/7$.
These are decimal displays of rational upper bounds; the
machine-readable audit records their exact numerators and denominators.
The fine tail is approximately $0.0353401933$, strictly below $1/4$.
~~~

In the response to referees, O-B6 should be marked “resolved by restored
evidence and clarified labeling”: the rational-profile value and the
combined value were being compared as though they were the same
quantity. O-B7 remains a genuine exposition correction and is fixed by
Section 3 above.

## 6. Packet convention and equal-rank invariance

For a coordinate in the additive group C_(p_i^a_i), if its element order
is p_i^v_i, then
\[
x_i\bmod p_i=0
\quad\Longleftrightarrow\quad v_i<a_i.
\]
In particular this includes both v_i=0 and v_i=1 when a_i=2. The packet
bit is the complement of the full-order indicator, not the indicator
of positive order exponent.

The defining packet is therefore
\[
t_T(x)=\prod_{i\in T}(1-p_i\,1_{\{v_i<a_i\}}).
\]
At full quotient order all packet factors equal one; the witness is zero.
At any quotient coatom exactly its one nonfull bit is set, and the
incidence equations give witness value one. These values were checked
exactly in the standalone script.

Suggested sentence immediately after the packet definition:

~~~latex
If $x_i$ has additive order $p_i^{v_i}$, then
$x_i\bmod p_i=0$ exactly when $v_i<a_i$.
Thus every packet depends only on which quotient coordinates
have full order; it does not distinguish the lower valuation
levels of a nonfull coordinate.
~~~

This makes the equal-rank argument transparent. Along comparable orders,
each full-order indicator is nondecreasing, D_0 is nonincreasing, and
U_0 is nondecreasing. Equality of their summed rank forces each such
increment to vanish. The packet bits, closure bits, and hence all
subsequent witness expressions are fixed. The referee's reversed
convention is incompatible with the paper's own coatom boundary values.

## 7. Moving-upper approximant

The current source already states:
\[
Y=r_AU_AU_{M_u},\qquad a=r_A\otimes1
\]
after grouping the aggregate upper factor A with its upper helper.
This is the safe explicit choice and should be retained.

Its annihilation follows from balance of the helper; it is exact on the
joint upper closure; and the unmodified lower donor supplies exactness on
the global lower closure. Its local error is at most the upper rank
bound. In particular, no assumption that an arbitrary pointwise rank
multiple of an annihilator remains an annihilator is needed. Nor does
this argument assume the three added two-prime factors are separately
balanced: their individual totals are nonzero.

The referee's description of an unstated moving term does not match the
explicit grouping paragraph at the pinned current source. This can be
recorded as an explicit presentational resolution in the new edition.
Do not choose a different unstated interpretation because its numerical
effect happens to be small.

## 8. Notation and extraction issues

### Closure notation

The manuscript identifies shell families with indicators. Consequently
DU=P and D_i U_i=P_i are mathematically correct *indicator products*.
For readability, distinguish the two forms at first use:

~~~latex
The lower and upper support closures have intersection equal
to the support. Equivalently, their indicators satisfy $DU=P$.
~~~

At the local version, state the set intersection and then retain the
indicator identity used by the interpolation formulas. Replacing every
indicator product by a set intersection would create new type ambiguity.

### Parity notation

In 03-boundaries.tex, replace
\[
D*(X+Y)\equiv D*D\equiv D(r)=1\pmod2
\]
with
\[
D*(X+Y)\equiv D*D\equiv D(r)\equiv1\pmod2.
\]
This respects the possible value D(r)=-1.

### Lambda typography

The existing displayed fraction is correct. A more explicit display is

~~~latex
\lambda=
\frac{E\,\left\lfloor 2^{367}/E\right\rfloor}{2^{367}}.
~~~

A PDF text extractor may still flatten the exponent. Verify the rendered
page rather than treating extraction alone as evidence of incorrect math.

### Abstract

The current main.tex contains the exact source string $2^u$. Preserve it
and inspect its final PDF rendering. There is no mathematical or source
correction required merely because an extractor returns “2u.”

## 9. Included files and applied edits

- verify_h100_error_budget.py — standalone exact check.
- h100_error_budget_result.json — exact results, safe bounds, source hashes.
- MATHEMATICAL_EDIT_REVIEW.md — this proof and explanation of the amendments.

The corrections have been applied to 03-boundaries.tex and
05-construction.tex. The latter now identifies the determinant-193 minor
as the first fifteen rows of the FIBERS table, points to the Pocklington
routine in ppi_modular_pair.py, and specifies that the ordinary slot order
is a fixed linear extension of divisibility. The existing grouped
moving-upper approximant was retained. All 25 labels and all 19 numbered
environments in these two files remain in their original order.

The numerical audit passed again from this included copy. Its exact
results are recorded in the adjacent JSON file. Compilation, rendering,
and the broader verification record are documented elsewhere in the
review package.
