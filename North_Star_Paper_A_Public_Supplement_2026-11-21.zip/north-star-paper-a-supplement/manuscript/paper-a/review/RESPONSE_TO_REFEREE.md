# Response to the supplied Muse referee report

**Manuscript:** Robert Gillon, *Reconstructing Unions of Subgroups from Cyclic Autocorrelation*.  
**Revision date:** 21 November 2026.  
**Report addressed:** The full Muse report supplied by the author on the 100-odd-prime revision dated 20 November 2026.  
**Purpose:** Record the corrections, source evidence, and remaining scope limitations accompanying the revised research draft.

The principal theorem and construction are unchanged: the explicit modulus is $N=2^{3446}M_{100}$ with exactly 100 distinct odd prime divisors, and the constructed divisor ideals have identical autocorrelation at every labeled shift and lie in different translation orbits. This revision repairs exposition and reproducibility. It does not claim a complete arithmetic classification of rigid moduli or a smaller counterexample.

The Muse report found the mathematical construction valid and identified defects in the cited support package. The present revision agrees with the principal reproducibility criticisms at the older cited commit. One numerical criticism requires a correction to the report itself: the existing Appendix A decimal was the combined error bound, while the smaller decimal computed by the referee was the rational contribution before blending. Fresh exact calculations reproduce both.

## Source revisions and available referee material

The original construction and data are at commit
`09d77232d96df1e16ef52917ddf46ccff90deb0b` in `rgillon/north-star-math`.
The complete source package inspected for this revision is at
`2ddc150f363da5ae410ed4ac1de573e7cbd7bb80`.
That later snapshot contains both H100 audit programs and all three Appendix B artifacts named in the report. Appendix A now cites the complete package separately from the original construction pin. The review archive supplies the relevant files directly.

The author also reported receiving Gemini and Grok referee reports. Their original full texts were not recovered during this revision. Accordingly, no precise verdict, quotation, objection, or claimed consensus is attributed to them here. An earlier assistant summary assigning exact verdicts to those reports was not adequately sourced and is not relied upon. This response can be extended against the original reports if they become available.

## O-B1: missing Appendix B artifacts

**Disposition: closed by supplying the files, correcting paths, and replaying their finite coverage.**

The archive includes the following under `manuscript/paper-a/graph-controls/`:

- `verify_extended_subgroups.py`;
- `extended_subgroup_results.json`;
- `replay_graph.cpp`, with `replay_moduli.txt` and `replay_counts.txt`;
- the initial-domain, radial, and symmetry checkers and their archived data.

The C++17 replay was compiled and executed at all 38 moduli. Its output exactly matches the supplied count record: 1,468,606 subgroup-union profiles and zero unanchored targets. The initial-domain Python run separately reproduced 2,183 profiles. The radial run reproduced 4,751 nonempty profiles and 9,817 flip instances; the symmetry run passed at all seven specified moduli.

The C++ output records profile counts and unanchored-target counts. The old phrase “profile and component counts” could imply counts of every component; it has been narrowed to what the program actually prints. The optional NumPy/Numba implementation is included but was not rerun in the present environment. Its entire 20-modulus count domain was covered by the fresh C++ replay.

## O-B2 and O-B4: directory naming and moving branch tips

**Disposition: closed by one canonical layout, complete source pins, and an offline archive.**

The old construction pin uses `experiments/`, whereas the previously circulated PDF said to run from `certificates/` without identifying a matching package root. The revised instructions start from the archive or repository root and use:

```sh
python3 experiments/ppi_100_prime_pair.py
python3 experiments/ppi_h100_independent_audit.py experiments
python3 experiments/ppi_h100_decoder_audit.py experiments
```

All three exact commands were executed successfully from the canonical repository root in this revision task. The root layout is reproduced in the archive. Historical proof notes are retained for provenance; their dated commands are not the canonical instructions for the new package.

A branch tip is not used as a source pin. Both the original construction commit and the complete later package commit are named in full. Repository access is unnecessary for executing the supplied files.

## O-B3: unavailable H100 audit programs and the 2,175-target claim

**Disposition: closed by supplying both programs and fresh execution.**

Both `ppi_h100_independent_audit.py` and `ppi_h100_decoder_audit.py` are included. Their implementations come from the complete later source snapshot, not the older construction pin. The arithmetic checker uses literal source tables and exact arithmetic without importing the original verifier routines. It freshly reproduced the incidence solves, all 65,536 upper and 16,384 lower packet states, the 100-prime modulus, and the error and precision comparisons. It certifies 92 odd primes by trial division and eight large helpers by Pocklington with explicit witnesses.

The decoder checker freshly reconstructed 2,175 targets over 87 levels and checked the specified lattice covers and physical subgroup-height ranges. The original verifier separately reconstructed 435 targets. Full outputs, source hashes, environment records, and exit-status receipts are supplied in `review/replay/`.

These target checks corroborate the universal interval/grid argument. Neither the revised paper nor this response treats 2,175 successful samples as a proof for every admissible target or every cyclic shift.

## O-B5: the nine control moduli

**Disposition: closed by naming the controls and distinguishing execution scopes.**

The nine moduli specified by the extended implementation's `selftest()` are
1, 2, 6, 12, 36, 60, 210, 420, and 756.
Their profile counts, including the empty profile, are respectively
2, 3, 6, 10, 20, 50, 168, 887, and 490.
Both the fresh initial-domain Python run and the C++ run confirm these counts. They are now stated in Appendix B.

The distinct optional `crosscheck_extended.py` samples 1,560 profiles under its configured settings: $20\cdot60+9\cdot40$. That optional NumPy/Numba command was not run here and is not described as an exhaustive enumeration. An unused dictionary with obsolete illustrative counts in the optional implementation was removed; the actual comparison with the correct JSON record is unchanged. The original file and a source-hygiene record are preserved with the replay evidence.

## O-B6: the Appendix A decimal

**Disposition: the referee's identification of the decimal as erroneous is corrected; the revised appendix labels all components.**

The fresh arithmetic audit and a separate targeted standard-library calculation give the following exact-rational bounds, shown in decimal only for readability:

| Bound divided by $\delta$ | Decimal summary |
| --- | ---: |
| Rational-profile contribution | $0.253421032143283461998513\ldots$ |
| Additional dyadic-blend contribution | $0.000508927601520494659597\ldots$ |
| Combined bound | $0.253929959744803956658110\ldots$ |

The two contributions add exactly as rational numbers. The original appendix explicitly described $0.2539299597$ as the **combined** bound; that number is reproduced. Replacing it with $0.2534210321$ would omit the blending contribution. The revised appendix retains the combined value and displays the split, eliminating the ambiguity behind the report's discrepancy. These quantities are certified error bounds, not observed approximation errors.

## O-B7: deriving the rational bound from the printed inequalities

**Disposition: the objection is valid and the written derivation is repaired.**

The loose estimate $\mathcal U<31$ does not yield a rational-profile error ratio below $0.254$; substitution gives approximately $0.2583332126$. The corrected display states the rigorously rounded bounds

\[
\mathcal U<\frac{6079}{200},\qquad
\mathcal L<\frac{2447}{1000},\qquad
\delta>\frac{1697}{10^7},\qquad
\eta<10^{-6}.
\]

Substitution into equation (9.11), divided by $\delta$, gives

\[
\frac{90242379537969}{355886694400000}
<\frac{253571}{10^6}
<\frac{127}{500}=\frac{254}{1000}.
\]

The revised text also gives a short displayed blend estimate. The odd denominator satisfies $E<2^{304}$, so $1-\lambda<2^{-63}$. Bounding the paired-anchor bracket by $8.1\times10^{12}$ yields a blend ratio below

\[
\frac{81\cdot10^{18}}{1697\cdot2^{63}}
<\frac{2}{231}=\frac{1}{33m},\qquad m=\frac72.
\]

Together these imply the stated final margin below $1/m$. The standalone program `review/numerics/verify_h100_error_budget.py` solves the incidence systems and checks these comparisons using exact fractions without importing construction or verifier modules. Its machine-readable result is supplied.

## O-B8: the disputed equal-rank invariance objection

**Disposition: no mathematical repair is required; the evaluation convention is made explicit.**

The report itself withdrew its initial defect claim after checking the packet convention. For an element of order $p_i^{v_i}$ in $C_{p_i^{a_i}}$,

\[
x_i\equiv0\pmod{p_i}\quad\Longleftrightarrow\quad v_i<a_i.
\]

This is the indicator used in the manuscript's quotient packet. It is not the indicator $v_i\ge1$ when $a_i=2$. The revised text states the equivalence beside the packet definition. Equal-rank comparability preserves the full-order indicators, hence the packet values and the deterministic decoder inputs, as the original proof requires. The current source already gives the grouped moving-upper approximant explicitly; that valid formula is retained.

## O-B9 and O-B10: ordering and presentation

**Disposition: clarified where needed, without changing the construction.**

The ordinary slots are selected by the stated mass criterion; the stored order is a fixed linear extension with the required early/late placement. The list need not be globally sorted by decreasing mass. One sentence now distinguishes selection from ordering.

The support notation now distinguishes the set equality $D\cap U=P$ from the equally valid pointwise indicator identity $DU=P$. The parity argument uses a congruence sign. The Pocklington routine's module is named, and the dyadic-blending display is made easier to read. The specified incidence minor is identified explicitly.

The abstract's $2^u$ was already typeset as a superscript; the flattened “2u” was a text-extraction artifact. The rendered revision is checked, without altering a correct exponent. The abstract now states explicitly that the count $2^u$ includes the given union, resolving the former wording “other subgroup unions.”

## O-B11, O-B12 and O-B13: scope and historical items

The referee's own corrected test bugs require no manuscript repair. They remain part of that report's process history rather than evidence against the final construction.

The six-factor research draft is not used in Theorem 1.1 or the graph classification. Its consequence remains explicitly conditional where mentioned. The present revision does not validate that external claim or incorporate later provisional collision-locus results.

The old November 19 sieve, prime-counting margin, and binomial-coefficient issues are absent from the H100 construction and require no changes here. No modification is made to a separate companion manuscript in this task.

## Review status after revision

The package supplies the revised manuscript, proof and source maps, all named audit and graph-control files, exact fresh outputs, and a content-hash manifest. Recorded executions support the listed finite claims; the universal arguments remain mathematical proofs for a reviewer to assess. The companion Lean status report records no supplied formalization and no build.
